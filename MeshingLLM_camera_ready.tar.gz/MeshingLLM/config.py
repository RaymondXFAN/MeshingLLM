"""MeshingLLM experiment configuration — review revision (ICEBE 2026 submission).

4 datasets (+SHOPPING Intent), 6 baselines (+FouRA/SeLoRA/LoCA).
Edit only this file; do not touch the hard-coded values inside the individual modules.

GPU mode toggle:
  Default = CPU mode (Qwen2.5-1.5B, device=cpu, batch=2)
  Set env var MESHINGLLM_GPU=1 → GPU mode (Qwen2.5-7B, device=cuda, batch=4)
  Before running on AutoDL: export MESHINGLLM_GPU=1
  Before running on Windows CMD: set MESHINGLLM_GPU=1
"""
import os
from dataclasses import dataclass, field
from typing import List, Tuple

# GPU mode detection: switch to the GPU config when env var MESHINGLLM_GPU=1
GPU_MODE = os.environ.get("MESHINGLLM_GPU", "0") == "1"


@dataclass
class Config:
    # ---- Base model ----
    # GPU mode: 7B (main paper data); CPU mode: 1.5B (local validation)
    base_model: str = "Qwen/Qwen2.5-7B" if GPU_MODE else "Qwen/Qwen2.5-1.5B"
    max_seq_len: int = 2048
    # GPU mode: cuda; CPU mode: cpu
    device: str = "cuda" if GPU_MODE else "cpu"
    # GPU mode: FP16 acceleration; CPU mode: FP32
    torch_dtype: str = "float16" if GPU_MODE else "float32"

    # ---- Datasets (4; SHOPPING Intent added in the review revision) ----
    data_root: str = "data"
    financebench: str = "PatronusAI/financebench"                       # GAP A primary domain (commerce-adjacent)
    mmlu_business_subsets: Tuple[str, ...] = (
        "professional_accounting",                                      # only 1 subset, intra-domain auxiliary
    )
    amazon_reviews: str = "srvmishra832/multilingual-amazon-reviews-6-languages"  # cross-segment slice (category + region) [original keung2019 deprecated]
    shopping_intent: str = "jtlicardo/ecommerce-intent-6k"            # e-commerce intent classification (original tasksource deprecated)
    # ---- Optional extras; unused in the released pipeline ----
    # banking77: str = "legacy-datasets/banking77"
    # clinc150: str = "PolyAI-NLP/clinc_oos"

    # ---- Meshing parameters ----
    cr_target: int = 16                  # target compression ratio (§3.4 conservative CR=16) — note: parameter compression, not inference speedup
    tau_energy: float = 0.85             # §3.5 energy threshold τ (with the AND-intersection strategy τ=0.85 → CR≈10x on 1.5B; ≈16x expected on 7B)
    k_clusters: int = 4                  # triangular spectral clustering K (elbow)
    freq_strategy: str = "energy+gradient"   # the conference version runs only energy+gradient and energy-only

    # ---- Three-level progressive inference ----
    level: str = "L2"                    # L1 / L2 / L3

    # ---- GPU-specific parameters ----
    # GPU mode: process more layers (7B has 28 layers vs 1.5B also 28 layers but each is larger)
    max_mesh_layers: int = 16 if GPU_MODE else 8   # GPU processes 16 layers, CPU only 8 (to bound compute)
    # GPU mode: matrix sub-block cap (7B weight matrices are larger)
    max_matrix_dim: int = 4096 if GPU_MODE else 2048   # GPU can handle 4096 sub-blocks, CPU only 2048

    # ---- Training ----
    lr: float = 1e-4
    epochs: int = 3
    # GPU mode: batch=4 (fits in RTX 4090 24GB); CPU mode: batch=2
    batch_size: int = 4 if GPU_MODE else 2
    seeds: Tuple[int, ...] = (42, 123)   # seeds used in the released experiments

    # ---- Notes on the Spectral PEFT baselines ----
    # The three baselines FouRA/SeLoRA/LoCA use "re-implementation following published descriptions"
    # (their official repos were unreleased/unstable at submission time); see the notes in train_eval.py
    # If the official repos become available, prefer them over this simplified implementation

    # ---- Output ----
    out_root: str = "outputs"

    def __post_init__(self):
        """Print a summary of the current config to confirm whether CPU or GPU mode is active."""
        mode = "GPU" if GPU_MODE else "CPU"
        print(f"[config] mode={mode}, base_model={self.base_model}, device={self.device}, "
              f"batch_size={self.batch_size}, max_mesh_layers={self.max_mesh_layers}, "
              f"max_matrix_dim={self.max_matrix_dim}")

    def segment_pairs(self) -> List[Tuple[str, str]]:
        """Cross-segment transfer — review revision: 3 pairs (category + region + cross-domain), reflecting the homogeneous–heterogeneous setup of Def 4."""
        return [
            ("amazon_electronics", "amazon_home"),     # category heterogeneity
            ("amazon_cn", "amazon_eu"),                # region heterogeneity
            ("financebench", "shopping_intent"),       # new: cross-domain transfer (finance → e-commerce intent)
        ]

    def baselines(self) -> List[str]:
        """Review-revision baselines: 6 (3 traditional + 3 direct frequency-domain PEFT competitors)."""
        return ["INT4-GPTQ", "LoRA-r8", "FullFT-approx",
                "FouRA", "SeLoRA", "LoCA"]
