#!/usr/bin/env bash
# ---- keep ALL caches on the data disk (the system disk is small) ------------------
export HF_HOME="${HF_HOME:-/root/autodl-tmp/hf_cache}"
export HF_HUB_CACHE="$HF_HOME/hub"
export HF_DATASETS_CACHE="$HF_HOME/datasets"
export TRANSFORMERS_CACHE="$HF_HOME/hub"
export PIP_CACHE_DIR="${PIP_CACHE_DIR:-/root/autodl-tmp/.pip_cache}"
export TMPDIR="${TMPDIR:-/root/autodl-tmp/tmp}"
mkdir -p "$HF_HOME" "$HF_HUB_CACHE" "$HF_DATASETS_CACHE" "$PIP_CACHE_DIR" "$TMPDIR" 2>/dev/null || true
# -------------------------------------------------------------------------

# =============================================================================
# run_p1_all.sh — MeshingLLM P1 full-pipeline "one-click background" runner (idempotent, re-runnable)
# -----------------------------------------------------------------------------
# Features:
#   * waits for an already-running similar task to finish before starting (no resource contention, no duplicate starts)
#   * completed steps are skipped automatically (checks whether the report file exists)
#   * fully non-interactive, no Ctrl+C needed
#   * on completion generates P1_SUMMARY.txt (all reports combined, view in one cat)
#
# Usage (one line, in the code directory):
#   cd /root/autodl-tmp/MeshingLLM
#   nohup bash run_p1_all.sh > logs/p1_boot.log 2>&1 &
#
# check progress (non-blocking, will not hang):
#   bash check.sh
#
# Optional environment variables:
#   MESHINGLLM_MODEL=/root/autodl-tmp/models/Qwen2.5-1.5B   # use a local model directory
#   P1_OFFLINE=1|0|auto   # offline mode (default auto: offline if an HF cache exists)
#   P1_BATCH=1  # set to 1 to use GPU mode (7B); requires export MESHINGLLM_GPU=1 first
# =============================================================================
set -uo pipefail
cd "$(dirname "$0")"

export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-8}"

LOG="logs/p1_all.log"
R="results/fidelity_honest"
mkdir -p logs "$R"

log() { echo "[$(date '+%F %T')] $*"; }

log "================ P1 start ================"
log "HF_ENDPOINT=$HF_ENDPOINT  OMP_NUM_THREADS=$OMP_NUM_THREADS"

# ---------- model / offline policy ----------
EXTRA=()
if [ -n "${MESHINGLLM_MODEL:-}" ]; then
  EXTRA=(--model "$MESHINGLLM_MODEL" --offline)
  log "using local model directory: $MESHINGLLM_MODEL (forced offline)"
else
  case "${P1_OFFLINE:-auto}" in
    1) export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1; log "offline mode: forced on" ;;
    0) unset HF_HUB_OFFLINE TRANSFORMERS_OFFLINE 2>/dev/null; log "offline mode: forced off" ;;
    *) if ls -d "$HOME"/.cache/huggingface/hub/models--Qwen--* >/dev/null 2>&1; then
         export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1; log "HF cache detected -> auto offline (no network)"
       else
         log "no HF cache -> online download (via hf-mirror)"
       fi ;;
  esac
fi

# ---------- 0. wait for an existing similar process to finish ----------
# Do not use bare pgrep -f: it also counts "a shell whose command line happens to contain the string",
#    which would make it wait on itself forever. Here we only recognize processes whose comm is python*.
_p1_pids() {
  local pid comm
  for pid in $(pgrep -f "measure_fidelity_honest\.py" 2>/dev/null); do
    [ "$pid" = "$$" ] && continue
    comm=$(ps -o comm= -p "$pid" 2>/dev/null | tr -d ' ')
    case "$comm" in
      python|python3|python3.*|python3.[0-9]*) echo "$pid" ;;
    esac
  done
}

RUNDAYS=0
if [ -n "$(_p1_pids)" ]; then
  log "detected an already-running measurement process: $(_p1_pids | tr '\n' ' ')"
  log "waiting for it to finish (checking every 30s, up to 6 hours) ..."
  while [ -n "$(_p1_pids)" ]; do
    sleep 30
    RUNDAYS=$((RUNDAYS + 1))
    if [ "$RUNDAYS" -ge 720 ]; then
      log "still running after 6 hours; continuing directly to avoid waiting forever (resource contention may occur)"
      break
    fi
  done
  log "existing task finished, continuing"
else
  log "no conflicting process"
fi

# ---------- step runner (idempotent) ----------
run_step() {
  local name="$1"; shift
  local report="$1"; shift
  if [ -f "$report" ]; then
    log "SKIP  $name (already exists: $(basename "$report"))"
    return 0
  fi
  log "RUN   $name"
  python3 measure_fidelity_honest.py "$@" 2>&1 | tee -a "$LOG"
  local rc=${PIPESTATUS[0]}
  log "DONE  $name  (exit=$rc)"
  return 0
}

run_step "Step1 energy-only all layers + τ sweep (main metric)" \
  "$R/fidelity_honest_report_energy-only_tau0.85.md" \
  --strategy energy-only --tau 0.85 --tau-sweep \
  --tau-list 0.3,0.5,0.6,0.7,0.8,0.85,0.9,0.95,0.99 \
  ${EXTRA[@]+"${EXTRA[@]}"}

run_step "Step2 energy+gradient fake gradients (evidence for the negative result)" \
  "$R/fidelity_honest_report_energy-gradient_tau0.85.md" \
  --strategy energy+gradient --tau 0.85 --grad-seeds 3 \
  ${EXTRA[@]+"${EXTRA[@]}"}

run_step "Step3 energy+gradient real domain gradients" \
  "$R/fidelity_honest_report_energy-gradient_tau0.85_real.md" \
  --strategy energy+gradient --tau 0.85 --grad-source real \
  --seg-dir data/shopping_intent \
  ${EXTRA[@]+"${EXTRA[@]}"}

# ---------- summary ----------
{
  echo "################  MeshingLLM P1 summary report  ################"
  echo "generated: $(date '+%F %T')"
  echo "mode: ${MESHINGLLM_GPU:+GPU(7B)}${MESHINGLLM_GPU:-CPU(1.5B)}"
  echo
  for f in "$R"/fidelity_honest_report_*.md; do
    [ -f "$f" ] || continue
    echo "=========================================================="
    echo "###  $(basename "$f")"
    echo "=========================================================="
    cat "$f"
    echo
  done
  echo "=========================================================="
  echo "###  output file list"
  echo "=========================================================="
  ls -lh "$R" 2>/dev/null || echo "(none)"
  echo
  echo "###  aggregate section in the key json"
  for j in "$R"/fidelity_honest_*.json; do
    [ -f "$j" ] || continue
    echo "--- $(basename "$j") ---"
    python3 -c "
import json,sys
d=json.load(open('$j'))
a=d.get('aggregate',{})
for k in ('n_layers','FI_trunc_mean','FI_trunc_model_level','FI_bound_mean','FI_bound_gap_max',
          'FI_blend_mean','tau_ret_mean','density_mean','CR_mean','coverage_energy_frac','elapsed_sec'):
    if k in a: print(f'  {k:26s}= {a[k]}')
" 2>/dev/null || echo "  (parse failed)"
  done
} > P1_SUMMARY.txt 2>&1

log "================ all done ================"
log "summary: $(pwd)/P1_SUMMARY.txt"
log "raw logs: $(pwd)/$LOG"
