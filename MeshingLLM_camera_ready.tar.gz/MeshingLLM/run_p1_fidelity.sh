#!/usr/bin/env bash
# ---- keep ALL caches on the data disk (the system disk is small) ------------------
export HF_HOME="${HF_HOME:-/root/autodl-tmp/hf_cache}"
export HF_HUB_CACHE="$HF_HOME/hub"
export HF_DATASETS_CACHE="$HF_HOME/datasets"
export TRANSFORMERS_CACHE="$HF_HOME/hub"
export PIP_CACHE_DIR="${PIP_CACHE_DIR:-/root/autodl-tmp/.pip_cache}"
export TMPDIR="${TMPDIR:-/root/autodl-tmp/tmp}"
mkdir -p "$HF_HOME" "$HF_HUB_CACHE" "$HF_DATASETS_CACHE" "$PIP_CACHE_DIR" "$TMPDIR" 2>/dev/null || true
# -------------------------------------------------------------------------

# =============================================================================
# run_p1_fidelity.sh — MeshingLLM honest fidelity measurement (serial, can run overnight)
# -----------------------------------------------------------------------------
# Usage (in the MeshingLLM code directory):
#   chmod +x run_p1_fidelity.sh
#   # CPU mode (Qwen2.5-1.5B):
#   nohup bash run_p1_fidelity.sh > logs/p1_main.log 2>&1 &
#   # GPU mode (Qwen2.5-7B):
#   export MESHINGLLM_GPU=1
#   nohup bash run_p1_fidelity.sh > logs/p1_main.log 2>&1 &
#
# Monitoring:
#   tail -f logs/p1_main.log
#   ls -lh results/fidelity_honest/
#
# Do not hide errors: use tee to keep the full output, and set -o pipefail so a mid-run failure stops execution
# =============================================================================
set -euo pipefail

cd "$(dirname "$0")"
export HF_ENDPOINT=https://hf-mirror.com
mkdir -p results/fidelity_honest logs

echo "############################################################"
echo "# MeshingLLM P1 honest fidelity measurement  start: $(date '+%F %T')"
echo "# mode: ${MESHINGLLM_GPU:+GPU(7B)}${MESHINGLLM_GPU:-CPU(1.5B)}"
echo "############################################################"

# ---------- Step 0: precheck (~2-5 minutes, only 2 layers) ----------
# Goal: first confirm 1) the model can be downloaded/loaded 2) DCT runs 3) JSON is written, before committing to a long job
echo ""
echo "===== [Step 0/4] precheck smoke (2 layers, about 2-5 minutes) ====="
python measure_fidelity_honest.py --smoke 2>&1 | tee logs/p1_00_smoke.log

echo ""
echo ">>> precheck done. If you can see json files under results/fidelity_honest/ below, disk writing works:"
ls -lh results/fidelity_honest/ || true

# ---------- Step 1: energy-only all layers + τ sweep (main metric) ----------
echo ""
echo "===== [Step 1/4] energy-only all layers + τ sweep ====="
python measure_fidelity_honest.py \
  --strategy energy-only --tau 0.85 --tau-sweep \
  --tau-list 0.3,0.5,0.6,0.7,0.8,0.85,0.9,0.95,0.99 \
  2>&1 | tee logs/p1_01_energy_only.log

# ---------- Step 2: energy+gradient (fake gradients) all layers -- record the negative result ----------
echo ""
echo "===== [Step 2/4] energy+gradient fake gradients multi-seed (evidence for the negative result) ====="
python measure_fidelity_honest.py \
  --strategy energy+gradient --tau 0.85 --grad-seeds 3 \
  2>&1 | tee logs/p1_02_and_random.log

# ---------- Step 3: energy+gradient (real domain gradients) all layers ----------
echo ""
echo "===== [Step 3/4] energy+gradient real domain gradients ====="
python measure_fidelity_honest.py \
  --strategy energy+gradient --tau 0.85 --grad-source real \
  --seg-dir data/shopping_intent \
  2>&1 | tee logs/p1_03_and_real.log || \
  echo "real gradients failed (data may not be downloaded); continuing -- please check data/shopping_intent/*.jsonl"

# ---------- summary ----------
echo ""
echo "===== [4/4] summary ====="
echo "output files:"
ls -lh results/fidelity_honest/ 2>/dev/null || echo "(none)"
echo ""
echo "============================================================"
echo "P1 all done: $(date '+%F %T')"
echo "Please paste back the contents of the following two files:"
echo "  1) the summary section at the end of logs/p1_01_energy_only.log"
echo "  2) results/fidelity_honest/fidelity_honest_report_energy-only_tau0.85.md"
echo "============================================================"
