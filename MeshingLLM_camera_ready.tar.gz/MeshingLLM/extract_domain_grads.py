#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
extract_domain_grads.py — extract **real domain gradients** ∇_W L_D
================================================================================
Approach: run backward on the LM loss of the base model over domain data and directly accumulate each target layer's p.grad (mean |grad|).
      A domain-gradient signal is obtained without LoRA fine-tuning; a LoRA variant is available as a --finetune upgrade.

Never use random gradients again -- the AND numbers of the draft were ruined by this bug.

First do the name-alignment check (1 minute, mandatory):
  python3 extract_domain_grads.py --model Qwen/Qwen2.5-1.5B --check-names

Formal extraction (~5-15 minutes per segment on 1.5B):
  python3 extract_domain_grads.py --model Qwen/Qwen2.5-1.5B \
      --jsonl data/amazon/en_electronics/train.jsonl \
      --out results/grads_en_electronics.npz

Offline self-test (no real model loaded; verifies accumulation and layer-name mapping):
  python3 extract_domain_grads.py --self-test
"""
from __future__ import annotations
import argparse, json, math, os, sys, time
from pathlib import Path

# HF_ENDPOINT must be set before importing transformers
os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")

import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

TARGET_KEYS = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")
TEXT_FIELDS = (("review_body",), ("prompt", "completion"), ("question", "answer"),
               ("instruction", "response"), ("text",), ("content",))


# ============================================================ text extraction
def pick_texts(rows, fields=None):
    """Get text from JSONL records; auto-detect when fields is not specified."""
    keys = fields or None
    if keys is None:
        for cand in TEXT_FIELDS:
            if all(c in rows[0] for c in cand):
                keys = list(cand)
                break
    if keys is None:
        raise SystemExit(f"[fatal] could not identify a text field; available fields: {list(rows[0].keys())}."
                         f"Please specify one with --text-fields, e.g. --text-fields review_body")
    print(f"[data] text fields = {keys}")
    out = []
    for r in rows:
        parts = [str(r.get(k, "") or "") for k in keys]
        t = "\n".join(p for p in parts if p.strip())
        if len(t.strip()) >= 20:
            out.append(t)
    return out


def read_jsonl(path, limit=0):
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:                                # noqa: BLE001
                continue
            if limit and len(rows) >= limit:
                break
    if not rows:
        raise SystemExit(f"[fatal] {path} has no parseable records")
    return rows


# ============================================================ self-test stubs
def _abs_to(g, dtype):
    """Take the absolute value of the gradient and move it to CPU; supports both torch and numpy backends."""
    if hasattr(g, "detach"):                      # torch.Tensor
        return g.detach().abs().to("cpu", torch_dtype(dtype)).numpy()
    return np.abs(np.asarray(g)).astype(dtype)    # numpy (for self-test)


def torch_dtype(dt):
    import torch
    return torch.float16 if dt == np.float16 else torch.float32


def accumulate(model, batches, names, fp16_acc=False, log_every=10, tag=""):
    """Run backward on each batch and accumulate |grad|; returns ({name: mean|grad|}, n_batches).
    The numeric and layer-name mapping closes the loop here -- this is the correctness core of all of E5."""
    dtype = np.float16 if fp16_acc else np.float32
    pmap = dict(model.named_parameters())
    acc = {n: np.zeros(tuple(pmap[n].shape), dtype=dtype) for n in names}
    nb = 0
    t0 = time.time()
    for bi, batch in enumerate(batches):
        out = model.forward(input_ids=batch, labels=batch)
        loss = out.loss
        loss.backward()
        for n in names:
            g = pmap[n].grad
            if g is not None:
                acc[n] += _abs_to(g, dtype)
        model.zero_grad(set_to_none=True)
        nb += 1
        if log_every and (bi + 1) % log_every == 0:
            print(f"  [{tag}] batch {bi+1}  ({time.time()-t0:.0f}s, loss={float(loss):.4f})", flush=True)
    return {n: acc[n].astype(np.float32) / max(nb, 1) for n in names}, nb


# ============================================================ self-test stubs (numpy, no torch needed)
class _P:
    def __init__(self, v):
        self.v = np.asarray(v, dtype=np.float64)
        self.grad = None
        self.shape = self.v.shape
        self.ndim = self.v.ndim

    def __pow__(self, k):
        return _P(self.v ** k)

    def zero_(self):
        self.grad = None


class _Loss(float):
    """A float that supports backward() (self-test stub: the gradient is prewritten in forward)."""
    def backward(self):
        pass


def _self_test():
    class Stub:
        """loss = Σ w²  ⇒  ∂loss/∂w = 2w (after per-batch normalization the mean is still 2|w|)."""

        def __init__(self):
            rng = np.random.default_rng(0)
            self.params = {
                "model.layers.0.self_attn.q_proj.weight": _P(rng.standard_normal((8, 8)) * 0.1),
                "model.layers.0.self_attn.o_proj.weight": _P(rng.standard_normal((8, 8)) * 0.1),
                "model.layers.1.mlp.gate_proj.weight": _P(rng.standard_normal((16, 8)) * 0.1),
                "model.layers.1.self_attn.q_proj.weight": _P(rng.standard_normal((8, 8)) * 0.1),
                "model.embed_tokens.weight": _P(rng.standard_normal((32, 8)) * 0.1),   # non-target, should be skipped
            }

        def named_parameters(self):
            return list(self.params.items())

        def zero_grad(self, set_to_none=True):
            for p in self.params.values():
                p.grad = None

        def forward(self, input_ids=None, labels=None):
            loss = sum(float((p.v ** 2).sum()) for p in self.params.values())
            for p in self.params.values():
                p.grad = 2.0 * p.v                 # d(Σw²)/dw
            return type("O", (), {"loss": _Loss(loss)})()

    m = Stub()
    names = target_param_names(m)
    print(f"[self-test] matched {len(names)} target layers (embed_tokens should be skipped)")
    for n in names:
        print("   ", n)
    assert len(names) == 4 and not any("embed" in n for n in names), "layer-name filtering error"
    acc, nb = accumulate(m, [None] * 4, names)
    ok = True
    for n, g in acc.items():
        exp = 2.0 * np.abs(m.params[n].v)
        err = float(np.abs(g - exp).max())
        print(f"  {n:44s} max|acc-exp| = {err:.3e}  {'OK' if err < 1e-6 else 'BAD'}")
        ok &= err < 1e-6
    print(f"[self-test] batches={nb}  ->", "PASS" if ok else "FAIL")
    return 0 if ok else 1


# ============================================================ core: gradient accumulation
def target_param_names(model):
    out = []
    for n, p in model.named_parameters():
        if p.ndim >= 2 and any(k in n for k in TARGET_KEYS):
            out.append(n)
    return out


# ============================================================ main flow
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="Qwen/Qwen2.5-1.5B")
    ap.add_argument("--jsonl", default=None)
    ap.add_argument("--text-fields", nargs="*", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--n-samples", type=int, default=0, help="0=all")
    ap.add_argument("--max-batches", type=int, default=64, help="how many batches to run (to save time)")
    ap.add_argument("--batch-size", type=int, default=1)
    ap.add_argument("--max-len", type=int, default=512)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--fp16-acc", action="store_true", help="accumulate in fp16 (halves memory)")
    ap.add_argument("--check-names", action="store_true", help="only do the layer-name alignment check, do not extract gradients")
    ap.add_argument("--self-test", action="store_true")
    a = ap.parse_args()

    if a.self_test:
        sys.exit(_self_test())

    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    print(f"[env] HF_ENDPOINT = {os.environ.get('HF_ENDPOINT')}")
    print(f"[env] loading {a.model} (device={a.device}, fp16)")
    tok = AutoTokenizer.from_pretrained(a.model, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        a.model, torch_dtype=torch.float16, low_cpu_mem_usage=True,
        trust_remote_code=True).to(a.device)
    model.eval()
    for p in model.parameters():
        p.requires_grad_(True)

    names = target_param_names(model)
    print(f"[names] {len(names)} target layers on the model side")

    if a.check_names:
        try:
            import measure_fidelity_parallel as MF
            mdir = MF._resolve_model_dir(a.model, None)
            st = MF._scan_tensors(mdir)
            st_keys = {n for n, _, _ in st}
            miss = sorted(st_keys - set(names))
            extra = sorted(set(names) - st_keys)
            print(f"[names] {len(st_keys)} on the safetensors side")
            print(f"[names] in safetensors but not in model: {len(miss)} {miss[:3]}")
            print(f"[names] in model but not in safetensors: {len(extra)} {extra[:3]}")
            print("[names]", "both sides match exactly, safe to extract gradients"
                  if not miss and not extra else "mismatch; resolve it before continuing")
        except Exception as e:                              # noqa: BLE001
            print(f"[names] cannot compare with safetensors: {e}")
        sys.exit(0)

    if not a.jsonl or not a.out:
        raise SystemExit("[fatal] --jsonl and --out are required (or use --check-names / --self-test)")

    rows = read_jsonl(a.jsonl, a.n_samples)
    texts = pick_texts(rows, a.text_fields)
    print(f"[data] {a.jsonl}: {len(texts)} usable samples")

    enc = tok(texts, truncation=True, max_length=a.max_len, padding=False)["input_ids"]
    batches = []
    for i in range(0, min(len(enc), a.max_batches * a.batch_size), a.batch_size):
        chunk = enc[i:i + a.batch_size]
        mx = max(len(c) for c in chunk)
        pad_id = tok.pad_token_id if tok.pad_token_id is not None else 0
        arr = np.full((len(chunk), mx), pad_id, dtype=np.int64)
        for j, c in enumerate(chunk):
            arr[j, :len(c)] = c
        batches.append(torch.tensor(arr, device=a.device))
    print(f"[run] will run {len(batches)} batches × {a.batch_size} samples, max_len={a.max_len}")

    grads, nb = accumulate(model, batches, names, a.fp16_acc, log_every=5, tag=Path(a.jsonl).stem)
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(str(out), **grads)
    sz = out.stat().st_size / 1e6
    print("=" * 88)
    print(f"domain gradients saved: {out}  ({sz:.1f} MB, {len(grads)} layers, {nb} batches)")
    print("Sampled per-layer mean |∇_W L_D|:")
    for n in list(grads)[:3]:
        print(f"   {n:52s} mean|g|={grads[n].mean():.3e}  max={grads[n].max():.3e}")
    print("=" * 88)
    print("Next: mesh_apply.py --strategy energy+gradient --grads", a.out)


if __name__ == "__main__":
    main()
