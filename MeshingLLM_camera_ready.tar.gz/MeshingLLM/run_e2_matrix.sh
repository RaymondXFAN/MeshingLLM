#!/usr/bin/env bash
# ---- keep ALL caches on the data disk (the system disk is small) ------------------
export HF_HOME="${HF_HOME:-/root/autodl-tmp/hf_cache}"
export HF_HUB_CACHE="$HF_HOME/hub"
export HF_DATASETS_CACHE="$HF_HOME/datasets"
export TRANSFORMERS_CACHE="$HF_HOME/hub"
export PIP_CACHE_DIR="${PIP_CACHE_DIR:-/root/autodl-tmp/.pip_cache}"
export TMPDIR="${TMPDIR:-/root/autodl-tmp/tmp}"
mkdir -p "$HF_HOME" "$HF_HUB_CACHE" "$HF_DATASETS_CACHE" "$PIP_CACHE_DIR" "$TMPDIR" 2>/dev/null || true
# -------------------------------------------------------------------------

# run_e2_matrix.sh — E2 downstream task evaluation matrix (idempotent: existing results are skipped automatically; safe to interrupt and resume)
#   Prerequisites: 1) data/ downloaded; 2) results/compressed/{L1,L2,L3}/ produced by mesh_apply.py
#   Usage: nohup bash run_e2_matrix.sh > logs/e2_boot.log 2>&1 &
set -u
cd /root/autodl-tmp/MeshingLLM
OUT=results/eval; mkdir -p "$OUT" logs

DENSE=Qwen/Qwen2.5-1.5B
ELEC=data/amazon/en_electronics/test.jsonl
HOMEK=data/amazon/en_home_improvement/test.jsonl
INT=data/shopping_intent/test.jsonl

run () {                                  # run <tag> <model> <task> <jsonl> [extra...]
  local tag="$1" model="$2" task="$3" jsonl="$4"; shift 4
  local o="$OUT/${tag}.json"
  if [ -f "$o" ]; then echo "[skip] $tag"; return; fi
  if [ ! -f "$jsonl" ]; then echo "[skip] $tag (missing $jsonl)"; return; fi
  if [ ! -e "$model" ] && [[ "$model" != Qwen/* ]]; then
    echo "[skip] $tag (missing model dir $model)"; return; fi
  echo "[run ] $tag  $(date +%H:%M:%S)"
  python3 eval_downstream.py --model "$model" --task "$task" --jsonl "$jsonl" \
      --out "$o" "$@" >> "logs/eval_${tag}.log" 2>&1 \
      && echo "[ ok ] $tag" || echo "[FAIL] $tag -> logs/eval_${tag}.log"
}

echo "################ PPL (domain perplexity) ################"
for seg in "$ELEC" "$HOMEK" "$INT"; do
  [ -f "$seg" ] || continue
  s=$(basename "$(dirname "$seg")")
  run "ppl_dense_$s" "$DENSE" ppl "$seg"
  run "ppl_int4_$s"  "$DENSE" ppl "$seg" --int4
  for L in L1 L2 L3; do
    run "ppl_${L}_$s" "results/compressed/$L" ppl "$seg"
  done
done

echo "################ sentiment (Amazon sentiment Acc / macro-F1) ################"
for seg in "$ELEC" "$HOMEK"; do
  [ -f "$seg" ] || continue
  s=$(basename "$(dirname "$seg")")
  run "sent_dense_$s" "$DENSE" sentiment "$seg"
  run "sent_int4_$s"  "$DENSE" sentiment "$seg" --int4
  for L in L1 L2 L3; do
    run "sent_${L}_$s" "results/compressed/$L" sentiment "$seg"
  done
done

echo "################ intent (e-commerce intent Acc / macro-F1) ################"
[ -f "$INT" ] && {
  run "int_dense" "$DENSE" intent "$INT"
  run "int_int4"  "$DENSE" intent "$INT" --int4
  for L in L1 L2 L3; do
    run "int_${L}" "results/compressed/$L" intent "$INT"
  done
}

echo "################ summary ################"
python3 - <<'PY'
import json, glob, os
rows = []
for f in sorted(glob.glob("results/eval/*.json")):
    d = json.load(open(f, encoding="utf-8"))
    rows.append((os.path.basename(f)[:-5], d.get("n"),
                 f"{d.get('perplexity'):.3f}" if "perplexity" in d else "-",
                 f"{d.get('accuracy'):.4f}" if "accuracy" in d else "-",
                 f"{d.get('macro_f1'):.4f}" if "macro_f1" in d else "-"))
print(f"{'tag':28s} {'n':>5s} {'PPL':>10s} {'Acc':>8s} {'F1':>8s}")
print("-" * 64)
for r in rows:
    print(f"{r[0]:28s} {str(r[1]):>5s} {r[2]:>10s} {r[3]:>8s} {r[4]:>8s}")
print(f"\n{len(rows)} results total -> results/eval/")
PY
echo "=== E2 matrix complete $(date) ==="
