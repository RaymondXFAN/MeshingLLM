#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
measure_baselines.py — measure the true fidelity of low-bit quantization baselines on the same batch of 196 weight matrices
================================================================================
Motivation: in Table I of the draft, the 36.47% for INT4-GPTQ comes from the "accuracy" field of results.txt, while CR is written as 16x and
      VRAM as 0.39GB -- inconsistent accounting (R2-2 / R3-3 already noticed). Reviewers ask for a same-definition, same-precision comparison.
      This script re-measures the quantization baselines under the **same F_W definition** on the **same batch of matrices**,
      and converts the MeshingLLM sparse representation into the same "bit budget" accounting to obtain comparable (CR_s, F_W) points.

What is measured (every method on every layer):
  · int8_pc   per-output-channel symmetric INT8 (s = max|W|/127)
  · int4_pc   per-output-channel symmetric INT4 (s = max|W|/7)
  · int4_g128 group-128 symmetric INT4 (GPTQ's common config; bits include fp16 scale+zero overhead)
  · nf4_g64   NF4 group-64 (QLoRA's common config)
  · int2_pc   per-output-channel symmetric INT2 (as the high-compression reference point)
  · hybrid    sparse truncation (τ) + 4-bit quantization of retained coefficients + 8-bit indices (MeshingLLM × INT4 combined)

Metrics: F_W = 1 - ||W-Ŵ||_F/||W||_F (layer-mean / whole-model energy-weighted), bits/param, CR_s = 16/bits.

Usage:
  python3 measure_baselines.py --model-dir /root/autodl-tmp/models/Qwen2.5-1.5B --jobs 12
  python3 measure_baselines.py --model Qwen/Qwen2.5-1.5B --jobs 12 --out results/baselines
Outputs: <out>/baselines.csv  <out>/baselines_report.md  <out>/baselines.json
"""
from __future__ import annotations
import argparse, csv, gzip, json, math, os, sys, time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
try:
    import measure_fidelity_parallel as MF       # reuse the native safetensors reader (including bf16)
except Exception as e:                            # noqa: BLE001
    raise SystemExit(f"[fatal] measure_fidelity_parallel.py is required in the same directory: {e}")

B_IDX = 8.0          # amortized index bits (measured: delta + varint ≈ 8 bit/index)
B_ORIG = 16.0

NF4_LEVELS = np.array([-1.0, -0.6961928009986877, -0.5250730514526367, -0.39491748809814453,
                       -0.28444138169288635, -0.18477343022823334, -0.09105003625154495, 0.0,
                       0.07958029955625534, 0.16093020141124725, 0.24611230194568634,
                       0.33791524171829224, 0.44070982933044434, 0.5626170039176941,
                       0.7229568362236023, 1.0], dtype=np.float64)


def q_sym(W, bits, group=None):
    """Symmetric uniform quantization. group=None -> per-row (output channel); group=k -> groups of k elements along each row."""
    W = W.reshape(len(W), -1) if W.ndim > 1 else W.reshape(1, -1)
    qmax = 2 ** (bits - 1) - 1
    if group is None:
        s = np.abs(W).max(axis=1, keepdims=True) / qmax
        s = np.where(s == 0, 1.0, s)
        return np.clip(np.round(W / s), -qmax - 1, qmax) * s
    m, n = W.shape
    pad = (-n) % group
    Wp = np.pad(W, ((0, 0), (0, pad))) if pad else W
    g = Wp.reshape(m, -1, group)
    s = np.abs(g).max(axis=2, keepdims=True) / qmax
    s = np.where(s == 0, 1.0, s)
    q = np.clip(np.round(g / s), -qmax - 1, qmax) * s
    return q.reshape(m, -1)[:, :n]


def q_nf4(W, group=64):
    """NF4 group quantization."""
    m, n = W.shape
    pad = (-n) % group
    Wp = np.pad(W, ((0, 0), (0, pad))) if pad else W
    g = Wp.reshape(m, -1, group)
    absmax = np.abs(g).max(axis=2, keepdims=True)
    absmax = np.where(absmax == 0, 1.0, absmax)
    x = g / absmax
    idx = np.abs(x[..., None] - NF4_LEVELS).argmin(axis=-1)   # nearest among the 16 NF4 codewords
    q = NF4_LEVELS[idx] * absmax
    return q.reshape(m, -1)[:, :n]


def bits_per_param(method, m, n):
    """Amortized bits per parameter for each method (including scale/zero/index overhead)."""
    if method.startswith("int"):
        b = int(method.split("_")[0][3:])
        if method.endswith("_g128"):
            return b + 32.0 / 128.0
        if method.endswith("_g32"):
            return b + 32.0 / 32.0
        return b + 16.0 / n
    if method == "nf4_g64":
        return 4.0 + 32.0 / 64.0
    if method == "nf4_g128":
        return 4.0 + 32.0 / 128.0
    raise KeyError(method)


METHODS = ("int8_pc", "int8_g128", "int4_pc", "int4_g32", "int4_g128",
           "nf4_g64", "nf4_g128", "int3_g128", "int2_pc", "int2_g128")


def _leb128(v: int) -> bytes:
    out = bytearray()
    while True:
        b = v & 0x7F
        v >>= 7
        out.append(b | (0x80 if v else 0))
        if not v:
            return bytes(out)


def _work(args):
    name, fp, shape, taus = args
    try:
        from meshing import dct2d, idct2d, compute_profile, select_freq
    except Exception as e:                                       # noqa: BLE001
        return {"layer": name, "error": f"failed to import meshing: {e}"}
    try:
        W = MF._read_tensor(fp, name)
    except Exception as e:                                       # noqa: BLE001
        return {"layer": name, "error": f"failed to read weights: {e}"}

    m, n = W.shape
    nrmW2 = float((W * W).sum())
    rows = []

    def add(method, Wq, bpp):
        err2 = float(((W - Wq) ** 2).sum())
        rows.append({"method": method, "bits_per_param": bpp,
                     "F_W": 1.0 - math.sqrt(err2 / max(nrmW2, 1e-300)),
                     "CR_s": B_ORIG / bpp, "err2": err2})

    for meth in METHODS:
        if meth.startswith("nf4"):
            Wq = q_nf4(W, group=int(meth.split("_g")[1]))
        elif meth.endswith("_pc"):
            Wq = q_sym(W, int(meth.split("_")[0][3:]))
        elif meth.endswith("_g128"):
            Wq = q_sym(W, int(meth.split("_")[0][3:]), group=128)
        else:
            Wq = q_sym(W, int(meth.split("_")[0][3:]), group=32)
        add(meth, Wq, bits_per_param(meth, m, n))

    # ---- hybrid: sparse truncation + 4-bit retained coefficients ----
    if taus:
        F = dct2d(W)
        E = F * F
        Etot = max(float(E.sum()), 1e-300)
        Gamma = compute_profile(F)
        for tau in taus:
            try:
                mask = select_freq(Gamma, "energy-only", W=W, grad=None, tau=tau)
            except Exception:                                    # noqa: BLE001
                continue
            dens = float(mask.mean())
            if dens <= 0:
                continue
            Fk = F * mask
            Wd = idct2d(Fk)                        # lossless-precision sparse reconstruction
            err_tr = float(((W - Wd) ** 2).sum())
            # further quantize the retained coefficients to 4-bit (per-output-channel symmetric)
            qmax = 7
            absmax_row = np.abs(Fk).max(axis=1, keepdims=True)
            safe = np.maximum(absmax_row, 1e-30) / qmax
            Fq = np.round(Fk / safe) * safe * mask   # non-retained positions are already 0
            Wq = idct2d(Fq)
            err_h = float(((W - Wq) ** 2).sum())
            fw_h = 1.0 - math.sqrt(err_h / max(nrmW2, 1e-300))

            # ---- measured index coding: varint / bitmap / +gzip ----
            idx = np.flatnonzero(mask.ravel())
            nidx = max(len(idx), 1)
            d = np.diff(np.concatenate(([-1], idx.astype(np.int64))))
            vb = b"".join(_leb128(int(x)) for x in d)
            b_varint = 8.0 * len(vb) / nidx
            bm = np.packbits(mask.ravel()).tobytes()
            b_bitmap = 8.0 * len(bm) / nidx
            b_gz = 8.0 * min(len(gzip.compress(vb, 9)), len(gzip.compress(bm, 9))) / nidx
            b_gz_varint = 8.0 * len(gzip.compress(vb, 9)) / nidx

            base = {"F_W": fw_h, "F_W_noquant": 1.0 - math.sqrt(err_tr / max(nrmW2, 1e-300)),
                    "CR_p_raw": 1.0 / dens, "err2": err_h, "density": dens, "tau": tau}
            for tag, b_idx in (("varint", b_varint), ("bitmap", b_bitmap), ("gzidx", b_gz)):
                bpp = dens * (4.0 + b_idx) + 16.0 / (m * n)
                rows.append(dict(base, method=f"hyb{tau:g}_int4_{tag}",
                                 bits_per_param=bpp, CR_s=B_ORIG / bpp,
                                 b_idx=b_idx, idx_bytes=len(vb) if tag != "bitmap" else len(bm)))
            rows.append(dict(base, method=f"hyb{tau:g}_16bit_bitmap",
                             bits_per_param=dens * (16.0 + b_bitmap) + 16.0 / (m * n),
                             CR_s=B_ORIG / (dens * (16.0 + b_bitmap) + 16.0 / (m * n)),
                             b_idx=b_bitmap))
            rows.append(dict(base, method=f"hyb{tau:g}_16bit_varint",
                             bits_per_param=dens * (16.0 + b_varint) + 16.0 / (m * n),
                             CR_s=B_ORIG / (dens * (16.0 + b_varint) + 16.0 / (m * n)),
                             b_idx=b_varint))
            if b_gz_varint > 0:
                rows.append(dict(base, method=f"hyb{tau:g}_gzvarint_note",
                                 bits_per_param=dens * (4.0 + b_gz_varint) + 16.0 / (m * n),
                                 CR_s=B_ORIG / (dens * (4.0 + b_gz_varint) + 16.0 / (m * n)),
                                 b_idx=b_gz_varint))
    return {"layer": name, "shape": [m, n], "nrmW2": nrmW2, "rows": rows}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-dir", default=None)
    ap.add_argument("--model", default="Qwen/Qwen2.5-1.5B")
    ap.add_argument("--jobs", type=int, default=0)
    ap.add_argument("--taus", default="0.5,0.6,0.7,0.85")
    ap.add_argument("--max-layers", type=int, default=0)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--out", default="results/baselines")
    a = ap.parse_args()
    if a.smoke:
        a.max_layers = a.max_layers or 2
        a.taus = "0.6,0.85"

    taus = [float(t) for t in a.taus.split(",") if t.strip()]
    # --jobs 0 -> auto, but CAPPED (os.cpu_count() reports HOST cores in a container).
    if a.jobs and a.jobs > 0:
        jobs = a.jobs
    else:
        _n = len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else (os.cpu_count() or 4)
        try:
            with open("/sys/fs/cgroup/cpu.max") as _fh:
                _q, _p = _fh.read().split()
            if _q != "max" and int(_p) > 0:
                _n = min(_n, max(1, int(_q) // int(_p)))
        except Exception:
            pass
        jobs = max(1, min(_n, 16) - 1) if _n > 1 else 1
    mdir = MF._resolve_model_dir(a.model, a.model_dir)
    print(f"[env] code dir = {MF.CODE_DIR}")
    print(f"[env] model dir = {mdir}")
    tensors = MF._scan_tensors(mdir)
    if a.max_layers:
        tensors = tensors[:a.max_layers]
    print(f"[scan] {len(tensors)} target 2D tensors | jobs={jobs} | hybrid taus={taus}")

    tasks = [(nm, fp, shp, taus) for nm, fp, shp in tensors]
    t0 = time.time()
    res, failed, done = [], [], 0
    with ProcessPoolExecutor(max_workers=jobs) as ex:
        futs = {ex.submit(_work, t): t[0] for t in tasks}
        for fu in as_completed(futs):
            r = fu.result()
            done += 1
            if "error" in r:
                failed.append(r)
            else:
                res.append(r)
            if done % 20 == 0 or done == len(tasks):
                print(f"  [progress] {done}/{len(tasks)} layers ({time.time()-t0:.0f}s)", flush=True)

    if not res:
        print("[fatal] no layer succeeded.", failed[:3]); sys.exit(1)

    tot_e = sum(r["nrmW2"] for r in res)
    keys = sorted({row["method"] for r in res for row in r["rows"]})
    out_rows = []
    for k in keys:
        sel = [row for r in res for row in r["rows"] if row["method"] == k]
        if not sel:
            continue
        err2 = 0.0
        for r in res:
            rr = [x["err2"] for x in r["rows"] if x["method"] == k]
            if rr:
                err2 += rr[0]
        out_rows.append({
            "method": k,
            "bits_per_param": float(np.mean([x["bits_per_param"] for x in sel])),
            "CR_s": float(np.mean([x["CR_s"] for x in sel])),
            "F_W_layer_mean": float(np.mean([x["F_W"] for x in sel])),
            "F_W_model_level": 1.0 - math.sqrt(err2 / max(tot_e, 1e-300)),
        })
    out_rows.sort(key=lambda r: r["bits_per_param"])

    od = Path(a.out); od.mkdir(parents=True, exist_ok=True)
    with open(od / "baselines.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(out_rows[0].keys()))
        w.writeheader()
        for r in out_rows:
            w.writerow({k: (round(v, 6) if isinstance(v, float) else v) for k, v in r.items()})
    with open(od / "baselines_report.md", "w", encoding="utf-8") as f:
        f.write("# Low-bit quantization baselines: same definition, same matrices\n\n")
        f.write(f"- matrices: {len(res)} (all target linear layers of Qwen2.5-1.5B)\n")
        f.write(f"- elapsed: {time.time()-t0:.0f}s, processes: {jobs}\n")
        f.write(f"- F_W = 1 - ||W-W_hat||_F/||W||_F (computed in FP64)\n\n")
        f.write("| method | bits/param | CR_s | F_W(layer-mean) | F_W(model-level) |\n|---|---|---|---|---|\n")
        for r in out_rows:
            f.write(f"| {r['method']} | {r['bits_per_param']:.3f} | {r['CR_s']:.2f}× | "
                    f"{100*r['F_W_layer_mean']:.2f}% | {100*r['F_W_model_level']:.2f}% |\n")
    with open(od / "baselines.json", "w", encoding="utf-8") as f:
        json.dump({"meta": {"model_dir": str(mdir), "n_layers": len(res), "jobs": jobs},
                   "summary": out_rows, "per_layer": res}, f, indent=2, ensure_ascii=False)

    print("\n" + "=" * 96)
    print(f"{'method':22s} {'bits/param':>10s} {'CR_s':>8s} {'F_W(layer)':>10s} {'F_W(model)':>11s}")
    for r in out_rows:
        print(f"{r['method']:22s} {r['bits_per_param']:10.3f} {r['CR_s']:7.2f}× "
              f"{100*r['F_W_layer_mean']:9.2f}% {100*r['F_W_model_level']:10.2f}%")
    print("=" * 96)
    print("CSV ->", od / "baselines.csv")


if __name__ == "__main__":
    main()
