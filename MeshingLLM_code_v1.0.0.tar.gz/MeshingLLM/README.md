# MeshingLLM

**Trigonometric Projection Meshing for LLM Weight Compression —
Reconstruction Fidelity Does Not Predict Downstream Usability**

Reference implementation and measurement scripts accompanying the paper. The
release contains (i) the compression operator, (ii) the full-coverage fidelity
sweep, (iii) the matched-bit-budget baselines, and (iv) the downstream
evaluation protocol used to produce every number and figure in the paper.

> **Core claim.** Weight-reconstruction fidelity is *not* a proxy for compressed-model
> quality. Spectral sub-band pruning is usable only in a thin sliver where the
> compression ratio is already negligible, and it is dominated by uniform INT4
> quantization at every operating point where the model survives.

---

## Key findings (all values measured, Qwen2.5-1.5B)

| Result | Value |
|---|---|
| Exact truncation identity | `F_W = 1 − sqrt(1 − τ_ret)`, verified to machine precision (`<= 1.8e-15`) on all 196 target matrices |
| Usable operating point | `τ = 0.99` : `F_W = 90.0 %`, `CR_s = 1.26x`, accuracy 90.9 % (dense 89.6 %) |
| Cliff | the model passes from intact to destroyed between `CR_s = 1.26x` and `1.63x` |
| Dominating baseline | uniform INT4 (group 128): `CR_s = 3.76x`, perplexity 37.1, accuracy 92.2 % |
| Index encoding | on an identical support, changing only the index code raises `CR_s` from 3.94x to 10.61x |

---

## Repository layout

```
MeshingLLM/
├── README.md                     <- this file
├── LICENSE                       <- MIT
├── CITATION.cff
├── requirements.txt
├── docs/
│   └── DEPLOYMENT.md             <- step-by-step deployment guide (local CPU / cloud GPU)
├── figures/                      <- Fig. 1-5 (PNG 300 dpi + PDF vector)
│
│  ── core framework ────────────────────────────────────────────────
├── config.py                     <- single source of configuration (CPU/GPU switch)
├── meshing.py                    <- operator Π_θ, profile Γ_D, definitions 1-4 (+ smoke test)
├── data_prep.py                  <- download datasets and build category/region/domain slices
├── train_eval.py                 <- baselines + MeshingLLM training / evaluation
├── stats_analysis.py             <- mean±std, CI, Wilcoxon, Holm correction
├── dp_variant.py                 <- DP variant (not used in the conference paper; kept for reference)
│
│  ── measurement / reproduction ────────────────────────────────────
├── measure_fidelity_parallel.py  <- multi-process fidelity sweep over all layers (no GPU needed)
├── measure_fidelity_honest.py    <- single-process variant of the sweep
├── measure_baselines.py          <- 10 quantization baselines + 3 index encodings
├── mesh_apply.py                 <- compression pipeline (produce a compressed checkpoint)
├── eval_downstream.py            <- downstream metrics (perplexity, sentiment accuracy / macro-F1)
├── extract_domain_grads.py       <- extract real domain fine-tuning gradients (for the AND criterion)
├── verify_theorem_offline.py     <- offline proof-check of the truncation identity
├── selftest_measure_fidelity.py  <- fast offline self-test (no model, no network)
├── plot_pareto.py                <- Pareto / trade-off plots
├── make_fake_model.py            <- create a tiny local model for pipeline debugging
│
│  ── run scripts ───────────────────────────────────────────────────
├── run_all.sh                    <- one-shot pipeline, local CPU
├── run_all_gpu.sh                <- one-shot pipeline, cloud GPU (AutoDL)
├── run_p1_all.sh                 <- fidelity sweep + baselines + theorem check
├── run_p1_fidelity.sh            <- fidelity sweep only
├── run_e2_matrix.sh              <- downstream evaluation matrix
├── fetch_model.sh                <- robust model download (mirror / ModelScope / offline)
└── check.sh                      <- non-blocking progress monitor
```

---

## Requirements

* Python 3.10+
* PyTorch 2.1+ (CUDA build recommended for the GPU path)
* See `requirements.txt`

The fidelity sweep and the theorem check run on **CPU only** and need no
accelerator; a full 196-matrix sweep completes in roughly 25 minutes on a
12-process CPU. The GPU path is used only for the 7B baseline sanity check.

---

## Installation

```bash
git clone https://github.com/<your-org>/MeshingLLM.git
cd MeshingLLM

# 1) PyTorch first — pick the build matching your driver
pip install torch --index-url https://download.pytorch.org/whl/cu124   # CUDA 12.4
# pip install torch --index-url https://download.pytorch.org/whl/cpu   # CPU only

# 2) remaining dependencies
pip install -r requirements.txt
```

For a complete, step-by-step walkthrough (local CPU, cloud GPU, and common
failure modes) see **[docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)**.

---

## Quickstart

### 0. Offline self-test (no model, no network — run this first)

```bash
python selftest_measure_fidelity.py     # prints a PASS/FAIL summary in seconds
python verify_theorem_offline.py        # checks F_W = 1 - sqrt(1 - tau_ret)
```

### 1. Local CPU pipeline

```bash
python data_prep.py                     # download datasets + build slices
python meshing.py                       # operator smoke test
python measure_fidelity_parallel.py     # full 196-matrix fidelity sweep
python measure_baselines.py             # quantization + index-encoding baselines
python eval_downstream.py               # downstream metrics
```

or, all at once:

```bash
bash run_all.sh
```

### 2. Cloud GPU pipeline (AutoDL)

```bash
export MESHINGLLM_GPU=1                 # switches config to Qwen2.5-7B / cuda / fp16
bash run_all_gpu.sh
```

`config.py` selects the model, device and precision **from the environment
variable alone** — no source edits are required:

| `MESHINGLLM_GPU` | Model | Device | Batch | Layers | Matrix cap | dtype |
|---|---|---|---|---|---|---|
| unset (default) | Qwen2.5-1.5B | cpu | 2 | 8 | 2048 | float32 |
| `1` | Qwen2.5-7B | cuda | 4 | 16 | 4096 | float16 |

---

## Reproducing the paper

| Paper item | Command |
|---|---|
| Truncation identity (Property 2) | `python verify_theorem_offline.py` |
| Table III — frequency-selection ablation | `python measure_fidelity_parallel.py` |
| Table II — main comparison | `python measure_baselines.py` |
| Table IV — downstream performance | `python eval_downstream.py` |
| Fig. 3 / Fig. 4 — cliff and bit budget | `python plot_pareto.py` |
| Fig. 5 — index encoding | `python measure_baselines.py` |

Outputs are written to the project directory (`outputs/`, `*.csv`, `*.json`).

---

## Datasets and models

| Role | Identifier |
|---|---|
| Base model (CPU) | `Qwen/Qwen2.5-1.5B` |
| Base model (GPU) | `Qwen/Qwen2.5-7B` |
| Domain data (finance) | `PatronusAI/financebench` |
| Domain data (business) | MMLU `professional_accounting` |
| Segment slices | `srvmishra832/multilingual-amazon-reviews-6-languages` |
| Intent slices | `jtlicardo/ecommerce-intent-6k` |

All datasets and models are downloaded from the Hugging Face Hub at run time.
Inside mainland China, set a mirror **before** importing `transformers`:

```bash
export HF_ENDPOINT=https://hf-mirror.com
```

---

## Notes on the baseline implementations

`FouRA`, `SeLoRA` and `LoCA` are **re-implementations following the published
descriptions** (their official repositories were not consistently available at
the time of writing); they are labelled as such wherever they appear. Settings
and results should be read with that caveat in mind.

---

## Reproducibility statement

* The energy-only fidelity family is fully deterministic.
* `F_W` is measured directly on the deployed representation for **every** target
  weight matrix (196/196), with no layer subsetting and no bound substitution.
* The support used in the AND control is a **synthetic-gradient instantiation**
  (fixed pseudo-random seed); it is reported as a control and not as an instance
  of domain-guided selection. A real domain-gradient instantiation is supported
  by `extract_domain_grads.py`.
* Downstream metrics are small-sample preliminary estimates (`n = 100` for
  perplexity; 77 items for accuracy).

---

## Citation

If you use this code, please cite:

```bibtex
@inproceedings{fan2026meshingllm,
  title     = {MeshingLLM: Trigonometric Projection Meshing for LLM Weight Compression},
  author    = {Fan, Xiaohu and Pang, Xuejiao and Wang, Lingling and Liu, Jiyao and Nie, Haining and Liu, Jianfeng},
  booktitle = {IEEE International Conference on e-Business Engineering (ICEBE)},
  year      = {2026}
}
```

---

## License

Released under the MIT License — see [LICENSE](LICENSE).

## Contact

Xuejiao Pang (corresponding author) — `9452@whxy.edu.cn`
