#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
plot_pareto.py — plot the "fidelity–compression" Pareto frontier from pareto_*.csv (Fig. 5(a) / Fig. 7(a))
Style: Morandi palette + Times New Roman + font size >= 12 + vector output (pdf)
Usage:
  python3 plot_pareto.py results/fidelity_parallel/pareto_full.csv --out Figure_7a_Pareto
"""
import argparse, csv
from collections import defaultdict
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "DejaVu Serif"],
    "font.size": 12, "axes.labelsize": 13, "xtick.labelsize": 12, "ytick.labelsize": 12,
    "legend.fontsize": 12, "axes.linewidth": 1.0,
    "savefig.dpi": 300, "figure.dpi": 150, "savefig.bbox": "tight",
})

# Morandi palette
COL = {"energy-only": "#7E9AA6", "energy+gradient": "#C9A9A6", "gptq": "#9A9A9A"}
MARK = {"energy-only": "o", "energy+gradient": "^"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv_path")
    ap.add_argument("--out", default="Figure_7a_Pareto")
    ap.add_argument("--gptq-cr", type=float, default=4.0)
    ap.add_argument("--gptq-fw", type=float, default=36.47)
    ap.add_argument("--annotate", action="store_true", help="annotate each point with its tau")
    a = ap.parse_args()

    d = defaultdict(list)
    with open(a.csv_path, encoding="utf-8") as f:
        for r in csv.DictReader(f):
            d[r["strategy"]].append((float(r["CR_p"]), float(r["F_W_mean"]) * 100, float(r["tau"])))

    fig, ax = plt.subplots(figsize=(6.4, 4.6))
    for strat, pts in d.items():
        pts.sort()
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        ax.plot(xs, ys, "-", color=COL.get(strat, "#888888"), lw=1.8, zorder=3,
                marker=MARK.get(strat, "o"), ms=7, mfc="white", mew=1.6,
                label=strat.replace("energy+gradient", "energy + gradient (AND)"))
        if a.annotate:
            for cx, cy, t in pts:
                ax.annotate(f"$\\tau$={t:g}", (cx, cy), textcoords="offset points",
                            xytext=(5, 6), fontsize=9, color="#444444")

    ax.axhline(a.gptq_fw, color=COL["gptq"], lw=1.2, ls="--", zorder=2)
    ax.scatter([a.gptq_cr], [a.gptq_fw], marker="s", s=95, color=COL["gptq"], zorder=5,
               label=f"INT4-GPTQ (reference, {a.gptq_cr:g}$\\times$)")
    ax.annotate(f"INT4-GPTQ\n({a.gptq_cr:g}$\\times$, {a.gptq_fw:.1f}%)",
                (a.gptq_cr, a.gptq_fw), textcoords="offset points", xytext=(8, -22),
                fontsize=10, color="#333333")

    ax.set_xlabel(r"Parameter compression ratio $CR_p$")
    ax.set_ylabel(r"Weight reconstruction fidelity $F_W$ (%)")
    ax.set_ylim(0, 105)
    ax.grid(alpha=0.3, linestyle=":")
    ax.legend(frameon=False, loc="lower left")
    fig.tight_layout()
    for ext in ("pdf", "png"):
        fig.savefig(f"{a.out}.{ext}")
    print("Saved:", f"{a.out}.pdf", f"{a.out}.png")


if __name__ == "__main__":
    main()
