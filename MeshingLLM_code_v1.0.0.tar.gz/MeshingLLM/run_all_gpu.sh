#!/usr/bin/env bash
# ============================================================
# run_all_gpu.sh — one-command reproduction script for MeshingLLM on an AutoDL cloud GPU
# ============================================================
# Target config: RTX 4090 (24GB) / CUDA 12.8 / PyTorch cu124
# All data and the project must live under /root/autodl-tmp/!
# ============================================================
# Project path auto-detection:
#   the script automatically finds its own directory as the project root,
#   and works whether the folder is named MeshingLLM or experiment_code!
# ============================================================
set -e

# ---- auto-detect the project path (the script's directory = the project root) ----
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="${SCRIPT_DIR}"
DATA_DIR="${PROJECT_DIR}/data"
OUTPUT_DIR="${PROJECT_DIR}/outputs"

echo "================================================"
echo "  MeshingLLM - ICEBE 2026 - AutoDL GPU experiments"
echo "  base model: Qwen2.5-7B (FP16 on RTX 4090)"
echo "  datasets: FinanceBench + MMLU + Amazon + SHOPPING Intent"
echo "  baselines: GPTQ + LoRA-r8 + FullFT + FouRA + SeLoRA + LoCA"
echo "  CR = parameter compression ratio (not an inference speedup; see paper §6.2(1))"
echo "  project path (auto-detected): ${PROJECT_DIR}"
echo "================================================"

# ---- Step 0: environment setup ----
echo ""
echo "==== [Step 0/7] environment check and setup ===="

# check the GPU
echo "[0] checking GPU ..."
nvidia-smi || { echo "GPU unavailable! Please check that the AutoDL instance is healthy"; exit 1; }
echo "GPU available"

# set the HF mirror (required in mainland China!)
export HF_ENDPOINT=https://hf-mirror.com
echo "[0] HF mirror set: $HF_ENDPOINT"

# set GPU mode
export MESHINGLLM_GPU=1
echo "[0] MeshingLLM GPU mode enabled (MESHINGLLM_GPU=1)"

# create the data and output directories (if missing)
mkdir -p "${DATA_DIR}"
mkdir -p "${OUTPUT_DIR}"
mkdir -p "${OUTPUT_DIR}/tables"

# check that the code exists (auto-detected directory, independent of the folder name)
if [ ! -f "${PROJECT_DIR}/config.py" ]; then
    echo "code files not found! config.py is not in ${PROJECT_DIR}/"
    echo ""
    echo "Please make sure:"
    echo "   1. the code zip is extracted into some directory"
    echo "   2. run_all_gpu.sh and config.py are in the same directory"
    echo "   3. then run bash run_all_gpu.sh in that directory"
    echo ""
    echo "   find the code location: find /root/autodl-tmp -name 'config.py' 2>/dev/null"
    exit 1
fi
echo "code ready: ${PROJECT_DIR}/"

# ---- Step 1: install dependencies ----
echo ""
echo "==== [Step 1/7] install Python dependencies ===="

# first check whether PyTorch is installed and CUDA-enabled
echo "[1] checking PyTorch ..."
python -c "import torch; print(f'PyTorch={torch.__version__}, CUDA={torch.cuda.is_available()}')" 2>/dev/null || {
    echo "[1] PyTorch not installed or lacks CUDA support; installing PyTorch cu124 ..."
    pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu124
}

# verify CUDA
python -c "import torch; assert torch.cuda.is_available(), 'CUDA unavailable!'; print('PyTorch CUDA available')"
echo "PyTorch environment OK"

# install other dependencies
echo "[1] installing other dependencies ..."
pip install transformers datasets peft scipy pandas scikit-learn numpy accelerate -q
echo "dependencies installed"

# try to install auto-gptq (needed by the INT4-GPTQ baseline; skip and use simulated quantization if it fails)
echo "[1] trying to install auto-gptq (optional; failure does not affect other experiments) ..."
pip install auto-gptq --extra-index-url https://huggingface.github.io/autogptq-index/whl/cu124/ 2>/dev/null || {
    echo "auto-gptq installation failed; the INT4-GPTQ baseline will use simulated quantization (does not affect other experiments)"
}

# ---- Step 2: data preparation ----
echo ""
echo "==== [Step 2/7] download 4 datasets + slice ===="
cd "${PROJECT_DIR}"
python data_prep.py
echo "data preparation complete"

# ---- Step 3: core-algorithm smoke test ----
echo ""
echo "==== [Step 3/7] MeshingLLM core-algorithm smoke test ===="
cd "${PROJECT_DIR}"
python meshing.py
echo "smoke test passed"

# ---- Step 4: frequency-domain PEFT baselines ----
echo ""
echo "==== [Step 4/7] frequency-domain PEFT baselines (FouRA/SeLoRA/LoCA) ===="
cd "${PROJECT_DIR}"
python train_eval.py --mode spectral_peft
echo "frequency-domain PEFT baselines complete"

# ---- Step 5: all experiments ----
echo ""
echo "==== [Step 5/7] all experiments (MeshingLLM + baselines + cross-segment + ablation) ===="
echo "this step is the slowest (7B model loading + 16-layer meshing); estimated 15-30 minutes"
cd "${PROJECT_DIR}"
python train_eval.py --mode all
echo "all experiments complete"

# ---- Step 6: statistical analysis ----
echo ""
echo "==== [Step 6/7] statistical analysis ===="
cd "${PROJECT_DIR}"
python stats_analysis.py --results "${OUTPUT_DIR}/results.jsonl" --metric accuracy --target "MeshingLLM (L2)"
echo "statistical analysis complete"

# ---- Step 7: result summary ----
echo ""
echo "==== [Step 7/7] result summary ===="
echo ""
echo "================================================"
echo "  all experiments complete!"
echo ""
echo "  project path: ${PROJECT_DIR}"
echo ""
echo "  result files:"
echo "    ${OUTPUT_DIR}/results.jsonl          -- raw experiment data"
echo "    ${OUTPUT_DIR}/tables/accuracy_table.md -- statistics table"
echo "    ${OUTPUT_DIR}/tables/accuracy_compare.csv -- comparison tests"
echo ""
echo "  next steps:"
echo "    1. view results: cat ${OUTPUT_DIR}/results.jsonl"
echo "    2. fill the real numbers into the paper's §5.2-§5.4 tables"
echo "    3. stop billing: click 'Shutdown' in the AutoDL console"
echo ""
echo "  Before shutting down, be sure to download the outputs/ directory locally!"
echo "     after shutdown the data disk (/root/autodl-tmp/) is retained,"
echo "     but data is lost once the instance is released!"
echo ""
echo "  note: FouRA/SeLoRA/LoCA are simplified re-implementations"
echo "  if the official repos become available, prefer them over these"
echo "================================================"
