#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
measure_fidelity_parallel.py — parallel MeshingLLM fidelity / Pareto-frontier measurement
=====================================================================================
Three improvements over the serial version:
  1) **Multiprocess parallelism**: layers are independent -> dispatch per layer to N processes (utilization 130% -> ~N×100%)
  2) **No model loading**: read weights directly from safetensors -> no transformers / no network / zero VRAM
  3) **Full Pareto frontier in one pass**: run all (strategy × τ × grad_seed) within a single (layer) task,
     and additionally compute **index overhead b_idx and serialization compression ratio CR_s** (addressing review R3-2)

Metrics (consistent with the serial version):
  τ_ret   measured retained-energy fraction   ρ mask density   CR_p = 1/ρ
  b_idx   amortized index bits (measured delta + varint)   CR_s serialization compression ratio including indices
  F_W     honest weight-reconstruction fidelity (**measured with a real IDCT**, not analytically substituted)
  Theorem check F_W =? 1 - sqrt(1 - τ_ret)   (should be equal to machine precision)

Usage (one line, in the code directory):
  # default: 2 strategies × 9 τ values × 3 gradient seeds, all layers, auto N-1 processes
  python3 measure_fidelity_parallel.py --model-dir /root/autodl-tmp/models/Qwen2.5-1.5B

  # quick smoke test (2 layers, 1-2 minutes)
  python3 measure_fidelity_parallel.py --model-dir ... --smoke

  # adjust process count and tasks
  python3 measure_fidelity_parallel.py --model-dir ... --jobs 12 \
      --strategies energy-only,energy+gradient --taus 0.5,0.6,0.7,0.75,0.8,0.85,0.9,0.95,0.99

Outputs:
  <out>/pareto.csv      <- one row per (strategy,τ), used for Fig.5(a)/Fig.7(a)
  <out>/aggregate.json  -> machine-readable full data
  <out>/report.md       -> human-readable summary table
=====================================================================================
"""
from __future__ import annotations
import argparse, json, math, os, sys, time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

TARGET_KEYS = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")
B_VAL = 16      # FP16 coefficient
B_ORIG = 16     # the original is also counted as FP16 (same-precision comparison, addressing the review comment "6.2GB vs 0.57GB inconsistent precision")


# ---------------------------------------------------------------- code-directory discovery
def _discover_code_dir():
    for c in [Path(os.environ.get("MESHINGLLM_DIR", "")), SCRIPT_DIR, SCRIPT_DIR.parent,
              SCRIPT_DIR / "paper_materials" / "06_code",
              SCRIPT_DIR.parent / "paper_materials" / "06_code",
              Path("/root/autodl-tmp/MeshingLLM"), Path.cwd()]:
        try:
            if c and (c / "meshing.py").is_file():
                return c
        except Exception:
            continue
    return None


CODE_DIR = _discover_code_dir()
if CODE_DIR and str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))


# ---------------------------------------------------------------- model-directory resolution
def _resolve_model_dir(model, model_dir):
    if model_dir:
        p = Path(model_dir)
        if p.is_dir():
            return p
        raise SystemExit(f"[fatal] --model-dir is not a directory: {p}")
    if model:
        org, _, name = model.partition("/")
        base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{org}--{name}" / "snapshots"
        if base.is_dir():
            snaps = sorted(base.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
            if snaps:
                return snaps[0]
        raise SystemExit(f"[fatal] {model} not found in the HF cache; please point to a path with --model-dir")
    raise SystemExit("[fatal] --model-dir or --model is required")


# ---------------------------------------------------------------- native safetensors reading
# [Why not use safe_open] Qwen2.5 weights are **bfloat16**, and numpy does not understand bf16:
#   safe_open(framework="np").get_tensor(...) throws
#   "data type 'bfloat16' not understood".
#   So instead we **parse the safetensors container ourselves**: 8B header length + JSON header + raw data section,
#   decoding dtype by dtype; bf16 is restored by "taking the high 16 bits into the high bits of float32".
#   Advantage: no dependency on torch / transformers / network, pure numpy; handles fp32 / fp16 / bf16 alike.
_MEM_DTYPES = {
    "F64": np.dtype("<f8"), "F32": np.dtype("<f4"), "F16": np.dtype("<f2"),
    "I64": np.dtype("<i8"), "I32": np.dtype("<i4"), "I16": np.dtype("<i2"),
    "I8": np.dtype("i1"), "U8": np.dtype("u1"), "BOOL": np.dtype("?"),
}


def _st_header(fp):
    """Read the safetensors header, returning (header_dict, data_section_offset)."""
    import struct
    with open(fp, "rb") as fh:
        raw = fh.read(8)
        if len(raw) < 8:
            raise IOError(f"{fp} is not a valid safetensors file (header-length read failed)")
        n = struct.unpack("<Q", raw)[0]
        hdr = json.loads(fh.read(n).decode("utf-8"))
    return hdr, 8 + n


def _scan_tensors(mdir):
    """Read only the safetensors header and list all 2D target tensors (name, filename, shape)."""
    st_files = sorted(mdir.glob("*.safetensors"))
    if not st_files:
        raise SystemExit(f"[fatal] no *.safetensors under {mdir}")
    out = []
    for fp in st_files:
        try:
            hdr, _ = _st_header(fp)
        except Exception as e:                               # noqa: BLE001
            print(f"[warn] skipping unparseable file {fp}: {e}", file=sys.stderr)
            continue
        for k, info in hdr.items():
            if k == "__metadata__":
                continue
            shp = tuple(info.get("shape", []))
            if len(shp) == 2 and any(t in k for t in TARGET_KEYS):
                out.append((k, str(fp), shp))
    if not out:
        raise SystemExit(f"[fatal] no 2D tensor matching {TARGET_KEYS} in {mdir}")
    return out


def _read_tensor(fp, name):
    """Decode a single tensor by dtype -> float64 (**bfloat16 supported**)."""
    hdr, base = _st_header(fp)
    if name not in hdr:
        raise KeyError(f"{name} not in {fp}")
    info = hdr[name]
    dt = str(info["dtype"]).upper()
    shape = tuple(info["shape"])
    b, e = info["data_offsets"]
    with open(fp, "rb") as fh:
        fh.seek(base + b)
        buf = fh.read(e - b)
    if dt == "BF16":
        # bf16 = the high 16 bits of float32: uint16 -> uint32 -> shift left 16 -> treat as float32
        arr = np.frombuffer(buf, dtype=np.dtype("<u2")).astype(np.uint32) << 16
        arr = arr.view(np.float32)
    elif dt in _MEM_DTYPES:
        arr = np.frombuffer(buf, dtype=_MEM_DTYPES[dt])
    else:
        raise TypeError(f"dtype not yet supported: {dt}")
    return arr.reshape(shape).astype(np.float64)


# ---------------------------------------------------------------- index overhead (measured)
def _index_overhead_bits(idx_sorted):
    """Ascending indices -> delta -> LEB128 varint; measures the amortized bit count."""
    if len(idx_sorted) == 0:
        return 0.0
    d = np.diff(np.concatenate(([-1], idx_sorted.astype(np.int64))))
    bits = 0
    for v in d:
        v = int(v)
        bits += max(1, (v.bit_length() + 6) // 7) * 8     # one byte per 7 bits
    return bits / len(idx_sorted)


# ---------------------------------------------------------------- per-layer worker
def _work(args):
    name, fp, shape, strategies, taus, grad_seeds, want_idct = args
    try:
        from meshing import dct2d, idct2d, compute_profile, select_freq, pi_theta
    except Exception as e:                                   # noqa: BLE001
        return {"layer": name, "error": f"failed to import meshing: {e}"}

    try:
        W = _read_tensor(fp, name)
    except Exception as e:                                   # noqa: BLE001
        return {"layer": name, "error": f"failed to read weights: {e}"}

    m, n = W.shape
    nrmW = float(np.linalg.norm(W))
    if nrmW <= 0:
        return {"layer": name, "error": "zero norm"}
    F = dct2d(W)
    E = F * F
    Etot = float(E.sum())
    Gamma = compute_profile(F)
    rows = []

    for strat in strategies:
        seeds = [None] if strat == "energy-only" else list(grad_seeds)
        for sd in seeds:
            grad = None
            if sd is not None:
                grad = np.random.default_rng(sd).standard_normal(W.shape) * 0.01
            for tau in taus:
                try:
                    mask = select_freq(Gamma, strat, W=W, grad=grad, tau=tau)
                except Exception:                            # noqa: BLE001
                    continue
                dens = float(mask.mean())
                if dens <= 0:
                    continue
                tau_ret = float(E[mask].sum() / max(Etot, 1e-30))
                # measure fidelity with a real IDCT (honest accounting), and check the identity along the way
                if want_idct:
                    Wd = pi_theta(W, mask)
                    fw = 1.0 - float(np.linalg.norm(W - Wd)) / nrmW
                else:
                    fw = 1.0 - math.sqrt(max(1.0 - tau_ret, 0.0))
                fbound = 1.0 - math.sqrt(max(1.0 - tau_ret, 0.0))
                # index overhead / serialization compression ratio
                idx = np.flatnonzero(mask.ravel())
                b_idx = _index_overhead_bits(idx)
                cr_p = 1.0 / dens
                cr_s = (m * n * B_ORIG) / max(len(idx) * (B_VAL + b_idx), 1e-9)
                rows.append({
                    "strategy": strat, "tau": tau, "grad_seed": sd,
                    "tau_ret": tau_ret, "density": dens, "CR_p": cr_p,
                    "b_idx": b_idx, "CR_s": cr_s,
                    "F_W": fw, "F_bound": fbound, "gap": abs(fw - fbound),
                    "nrmW2": nrmW * nrmW,
                    "err2": (nrmW * (1.0 - fw)) ** 2 if want_idct
                            else nrmW * nrmW * (1.0 - tau_ret),
                })
    del F, E, W
    return {"layer": name, "shape": list(shape), "rows": rows}


# ---------------------------------------------------------------- main flow
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-dir", default=None)
    ap.add_argument("--model", default="Qwen/Qwen2.5-1.5B")
    ap.add_argument("--jobs", type=int, default=0, help="0=auto (cpu-1)")
    ap.add_argument("--strategies", default="energy-only,energy+gradient")
    ap.add_argument("--taus", default="0.5,0.6,0.7,0.75,0.8,0.85,0.9,0.95,0.99")
    ap.add_argument("--grad-seeds", default="1000,1001,1002")
    ap.add_argument("--max-layers", type=int, default=0)
    ap.add_argument("--no-idct", action="store_true", help="skip the real IDCT (faster, but F_W is an analytical value)")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--out", default="results/fidelity_parallel")
    a = ap.parse_args()

    if a.smoke:
        a.max_layers = a.max_layers or 2
        a.taus = "0.6,0.85,0.99"

    strategies = [s.strip() for s in a.strategies.split(",") if s.strip()]
    taus = [float(t) for t in a.taus.split(",") if t.strip()]
    grad_seeds = tuple(int(s) for s in a.grad_seeds.split(",") if s.strip())
    jobs = a.jobs or max(1, (os.cpu_count() or 4) - 1)

    mdir = _resolve_model_dir(a.model, a.model_dir)
    print(f"[env] code dir = {CODE_DIR}")
    print(f"[env] model dir = {mdir}")

    tensors = _scan_tensors(mdir)
    if a.max_layers:
        tensors = tensors[:a.max_layers]
    print(f"[scan] {len(tensors)} target 2D tensors | strategies={strategies} "
          f"| taus={len(taus)} | grad_seeds={len(grad_seeds)} | jobs={jobs} "
          f"| real IDCT={'no' if a.no_idct else 'yes'}")

    tasks = [(nm, fp, shp, strategies, taus, grad_seeds, not a.no_idct)
             for nm, fp, shp in tensors]

    t0 = time.time()
    results, done, failed = [], 0, []
    with ProcessPoolExecutor(max_workers=jobs) as ex:
        futs = {ex.submit(_work, t): t[0] for t in tasks}
        for fu in as_completed(futs):
            r = fu.result()
            done += 1
            if "error" in r:
                failed.append((r["layer"], r["error"]))
            else:
                results.append(r)
            if done % 10 == 0 or done == len(tasks):
                el = time.time() - t0
                print(f"  [progress] {done}/{len(tasks)} layers  ({el:.0f}s, "
                      f"{el/max(done,1):.2f}s/layer)", flush=True)

    dt = time.time() - t0
    if not results:
        print("[fatal] no layer succeeded. Failed samples:", failed[:5])
        sys.exit(1)

    # ---------------- aggregation ----------------
    layer_energy2 = {r["layer"]: r["rows"][0]["nrmW2"] for r in results if r["rows"]}
    tot_energy2 = sum(layer_energy2.values())
    keys = sorted({(row["strategy"], row["tau"]) for r in results for row in r["rows"]},
                  key=lambda k: (k[0], k[1]))
    pareto, gaps = [], 0.0
    for strat, tau in keys:
        sel = [row for r in results for row in r["rows"]
               if row["strategy"] == strat and row["tau"] == tau]
        if not sel:
            continue
        g = lambda k: float(np.mean([x[k] for x in sel]))
        # model-level weighting: per layer use the average F_W of that configuration; error energy is weighted by layer energy
        err2 = 0.0
        for r in results:
            rr = [x["F_W"] for x in r["rows"] if x["strategy"] == strat and x["tau"] == tau]
            if not rr:
                continue
            err2 += layer_energy2[r["layer"]] * (1.0 - float(np.mean(rr))) ** 2
        gaps = max(gaps, max(x["gap"] for x in sel))
        pareto.append({
            "strategy": strat, "tau": tau,
            "tau_ret": g("tau_ret"), "density": g("density"),
            "CR_p": g("CR_p"), "b_idx": g("b_idx"), "CR_s": g("CR_s"),
            "F_W_mean": g("F_W"),
            "F_W_model_level": 1.0 - math.sqrt(err2 / max(tot_energy2, 1e-30)),
            "F_W_std_across_layers": float(np.std([x["F_W"] for x in sel])),
        })

    outdir = Path(a.out); outdir.mkdir(parents=True, exist_ok=True)
    tag = "smoke" if a.smoke else "full"
    with open(outdir / f"aggregate_{tag}.json", "w", encoding="utf-8") as f:
        json.dump({"meta": {"model_dir": str(mdir), "n_layers": len(results),
                            "n_tensors": len(tensors), "jobs": jobs,
                            "strategies": strategies, "taus": taus,
                            "grad_seeds": list(grad_seeds),
                            "real_idct": not a.no_idct,
                            "elapsed_sec": round(dt, 1),
                            "coverage_energy_frac": tot_energy2 / max(tot_energy2, 1e-30),
                            "theorem_gap_max": gaps},
                   "pareto": pareto, "per_layer": results}, f, indent=2, ensure_ascii=False)

    with open(outdir / f"pareto_{tag}.csv", "w", encoding="utf-8") as f:
        f.write("strategy,tau,tau_ret,density,CR_p,b_idx,CR_s,F_W_mean,F_W_model_level,F_W_std\n")
        for p in pareto:
            f.write(f"{p['strategy']},{p['tau']},{p['tau_ret']:.6f},{p['density']:.6f},"
                    f"{p['CR_p']:.4f},{p['b_idx']:.3f},{p['CR_s']:.4f},"
                    f"{p['F_W_mean']:.6f},{p['F_W_model_level']:.6f},{p['F_W_std_across_layers']:.6f}\n")

    md = [f"# MeshingLLM parallel fidelity / Pareto frontier ({tag})", "",
          f"- model: `{mdir}` | layers: {len(results)}/{len(tensors)} | processes: {jobs}",
          f"- strategies: {strategies} | τ: {taus} | grad_seeds: {list(grad_seeds)}",
          f"- real IDCT measurement: {'no (analytical)' if a.no_idct else 'yes'} | elapsed: {dt/60:.2f} minutes",
          f"- **theorem-check max deviation: {gaps:.2e}**", "",
          "| strategy | τ | τ_ret | ρ | CR_p | b_idx(bit) | CR_s | F_W(layer) | F_W(model) |",
          "|---|---|---|---|---|---|---|---|---|"]
    for p in pareto:
        md.append(f"| {p['strategy']} | {p['tau']} | {p['tau_ret']*100:.2f}% | {p['density']*100:.2f}% | "
                  f"{p['CR_p']:.2f}× | {p['b_idx']:.1f} | {p['CR_s']:.2f}× | "
                  f"{p['F_W_mean']*100:.2f}% | {p['F_W_model_level']*100:.2f}% |")
    if failed:
        md += ["", "## failed layers", ""] + [f"- `{n}`: {e}" for n, e in failed[:20]]
    (outdir / f"report_{tag}.md").write_text("\n".join(md), encoding="utf-8")

    # console Pareto
    print("\n" + "=" * 96)
    print(f"{'strategy':<18}{'tau':>6}{'τ_ret':>9}{'ρ':>9}{'CR_p':>8}{'CR_s':>8}{'F_W':>10}")
    for p in sorted(pareto, key=lambda x: (x["strategy"], -x["F_W_mean"])):
        print(f"{p['strategy']:<18}{p['tau']:>6}{p['tau_ret']*100:>8.2f}%"
              f"{p['density']*100:>8.2f}%{p['CR_p']:>7.2f}×{p['CR_s']:>7.2f}×{p['F_W_mean']*100:>9.2f}%")
    print("=" * 96)
    print(f"theorem-check max deviation = {gaps:.2e}   elapsed = {dt/60:.2f} minutes   processes = {jobs}")
    print(f"CSV  -> {outdir/f'pareto_{tag}.csv'}")
    print(f"MD   -> {outdir/f'report_{tag}.md'}")


if __name__ == "__main__":
    main()
