"""dp_variant.py — HierFed-DPBA branch: adaptive differential privacy + PBFT consensus interface.

Corresponds to the MeshingLLM-DP baseline (ε=3) in §5.1 of the paper; foreshadows GAP D multi-party e-commerce collaboration.
This file provides reusable privacy-consensus primitives that can be plugged into the meshing training loop.

Math conventions:
  - Gaussian mechanism: apply L2 clipping (C) before adding noise to the gradient; noise ~ N(0, σ²), σ = C·√(2ln(1.5/δ))/ε
  - Adaptive budget: each round spends ε_t = ε_total / (T - t + 1) (monotonically decreasing; save toward the end)
  - PBFT: aggregation requires 2f+1 consistent nodes, tamper-proof (for multi-party e-commerce settings with no mutual trust)
"""
from __future__ import annotations
import numpy as np


class AdaptiveDP:
    def __init__(self, epsilon: float = 3.0, delta: float = 1e-5):
        self.epsilon_total = epsilon
        self.delta = delta
        self.used = 0.0

    def _sigma(self, C: float, eps_step: float) -> float:
        return C * np.sqrt(2 * np.log(1.5 / self.delta)) / max(eps_step, 1e-6)

    def step_epsilon(self, round_idx: int, total: int) -> float:
        """Adaptive budget: ε_t = ε_total/(T-t+1)."""
        eps_step = self.epsilon_total / (total - round_idx + 1)
        self.used += eps_step
        return eps_step

    def clip_and_noise(self, grad: np.ndarray, C: float = 1.0,
                       round_idx: int = 0, total: int = 1) -> np.ndarray:
        eps_step = self.step_epsilon(round_idx, total)
        sigma = self._sigma(C, eps_step)
        norm = np.linalg.norm(grad)
        if norm > C:
            grad = grad * (C / norm)
        noise = np.random.default_rng().normal(0, sigma, grad.shape)
        return grad + noise


class PBFTConsensus:
    """PBFT consensus: guarantees the integrity (tamper-proofing) of multi-party meshing-parameter aggregation."""

    def __init__(self, n_nodes: int = 4, f: int = 1):
        assert n_nodes >= 3 * f + 1, "PBFT requires n >= 3f+1"
        self.n, self.f = n_nodes, f

    def aggregate(self, updates: list[np.ndarray]) -> np.ndarray:
        """Aggregate only when there are >= 2f+1 consistent updates; otherwise raise (Byzantine warning)."""
        if len(updates) < 2 * self.f + 1:
            raise RuntimeError(f"[PBFT] only {len(updates)} updates, fewer than 2f+1={2*self.f+1}")
        stack = np.stack(updates, axis=0)
        median = np.median(stack, axis=0)
        # Consistency check: the deviation of most nodes from the median is within tolerance
        dev = np.mean(np.abs(stack - median), axis=tuple(range(1, stack.ndim)))
        if np.mean(dev < 1e-2) < (2 * self.f + 1) / self.n:
            raise RuntimeError("[PBFT] Byzantine deviation detected")
        return median


def meshing_with_dp(W, Gamma, mask, dp: AdaptiveDP, consensus: PBFTConsensus,
                     local_grads: list[np.ndarray], round_idx: int, total: int):
    """Superimpose DP noise + PBFT aggregation onto the meshing operation (GAP D preview)."""
    noised = [dp.clip_and_noise(g, round_idx=round_idx, total=total) for g in local_grads]
    agg = consensus.aggregate(noised)
    return W + agg  # simplification: add the aggregated delta back to the flow (in practice one should mesh over Γ/coefficients)


if __name__ == "__main__":
    dp = AdaptiveDP(epsilon=3.0)
    cons = PBFTConsensus(n_nodes=4, f=1)
    g = [np.ones((4, 4)) * i for i in (1.0, 1.0, 1.0, 0.9)]  # 3 consistent + 1 deviating
    agg = cons.aggregate(g)
    print("[dp] ε used this step:", round(dp.step_epsilon(0, 5), 3))
    print("[pbft] aggregated shape:", agg.shape)
