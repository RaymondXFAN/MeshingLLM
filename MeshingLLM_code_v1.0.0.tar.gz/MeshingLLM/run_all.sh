#!/usr/bin/env bash
# run_all.sh — one-command reproduction of the MeshingLLM ICEBE2026 review-revision experiments (CPU version)
# Path auto-detection: the script's directory = the project root
set -e

# auto-detect the project path
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "${SCRIPT_DIR}"

echo "================================================"
echo "  MeshingLLM - ICEBE 2026 review-revision experiments (CPU mode)"
echo "  project path (auto-detected): ${SCRIPT_DIR}"
echo "  datasets: FinanceBench + MMLU-Accounting + Amazon + SHOPPING Intent"
echo "  baselines: GPTQ + LoRA-r8 + FullFT-approx + FouRA + SeLoRA + LoCA"
echo "  CR = parameter compression ratio (not an inference speedup; see paper §6.2(1))"
echo "================================================"

echo ""
echo "==== [1/5] data preparation (download 4 datasets + slice) ===="
python data_prep.py

echo ""
echo "==== [2/5] MeshingLLM core-algorithm smoke test (including QR->mask verification) ===="
python meshing.py

echo ""
echo "==== [3/5] frequency-domain PEFT baselines (FouRA/SeLoRA/LoCA -- new in the review revision) ===="
python train_eval.py --mode spectral_peft

echo ""
echo "==== [4/5] all experiments (traditional baselines + MeshingLLM + cross-segment + ablation) ===="
python train_eval.py --mode all

echo ""
echo "==== [5/5] statistical analysis ===="
# path fix: outputs is under the project root, not ../outputs/
python stats_analysis.py --results outputs/results.jsonl --metric accuracy --target "MeshingLLM (L2)"

echo ""
echo "================================================"
echo "  DONE! Take the real numbers from outputs/results.jsonl"
echo "  fill them into the paper's §5.2-§5.4 tables and you are ready to submit"
echo ""
echo "  result file location: ${SCRIPT_DIR}/outputs/"
echo ""
echo "  note: FouRA/SeLoRA/LoCA are simplified re-implementations"
echo "  if the official repos become available, prefer them over these"
echo "================================================"
