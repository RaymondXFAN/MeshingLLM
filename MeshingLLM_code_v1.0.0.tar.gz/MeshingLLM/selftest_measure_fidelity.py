#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
selftest_measure_fidelity.py — inject stub torch and run measure_fidelity_honest.py offline
to exercise its real functions (prepare_layer / analyze_layer), confirming the code path is verified before running on the server.

Run: python3 selftest_measure_fidelity.py
"""
import sys, types, math
from pathlib import Path
import numpy as np

# ---- 1. stub torch (no torch in the sandbox; only to let module-level imports pass) ----
torch = types.ModuleType("torch")
dist = types.ModuleType("torch.distributed")
tmod = types.ModuleType("torch.distributed.tensor")
torch.distributed = dist
dist.tensor = tmod
sys.modules.update({"torch": torch, "torch.distributed": dist, "torch.distributed.tensor": tmod})

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))


def _find_code_dir():
    """Find the directory containing meshing.py (script dir / parent / paper_materials/06_code under the package / project dir)"""
    cands = [
        HERE, HERE.parent,
        HERE / "paper_materials" / "06_code",
        HERE.parent / "paper_materials" / "06_code",
        Path("/root/autodl-tmp/MeshingLLM"),
        Path.cwd(),
    ]
    for c in cands:
        try:
            if (c / "meshing.py").is_file():
                return c
        except Exception:
            continue
    return None


_CODE = _find_code_dir()
if _CODE is not None:
    sys.path.insert(0, str(_CODE))
    print(f"[selftest] code directory = {_CODE}")

try:
    import measure_fidelity_honest as M   # noqa: E402
except Exception as _e:                    # noqa: BLE001
    print("=" * 78)
    print("[selftest][fatal] failed to load measure_fidelity_honest")
    print(f"        original error: {_e}")
    print("=" * 78)
    sys.exit(1)

# measure_fidelity_honest uses fault-tolerant imports: when config/meshing are missing it does not crash at import time,
#    but is caught here -> giving a clean hint instead of dumping a traceback
if not getattr(M, "IMPORT_OK", True):
    print("=" * 78)
    print("[selftest][fatal] config.py / meshing.py not found; cannot verify.")
    print(f"        original error: {getattr(M, '_IMPORT_ERR', 'unknown')}")
    print("        Pick one of the following and re-run:")
    print("          1) export PYTHONPATH=$PWD/paper_materials/06_code")
    print("          2) export MESHINGLLM_DIR=/root/autodl-tmp/MeshingLLM")
    print("          3) Put this script together with measure_fidelity_honest.py in the code root (same level as meshing.py)")
    print("=" * 78)
    sys.exit(1)

def layer_like(m, n, seed=0, lowrank=8, scale=0.02):
    r = np.random.default_rng(seed)
    return (scale * (r.standard_normal((m, lowrank)) @ r.standard_normal((lowrank, n)))
            + 0.3 * scale * r.standard_normal((m, n))).astype(np.float64)

print("=" * 92)
print("A) prepare_layer + analyze_layer real code path | identity & metric-accounting comparison")
print("=" * 92)
hdr = f"{'shape':>12} {'strategy':>16} {'tau_set':>8} {'density':>9} {'CR':>7} {'tau_ret':>9} {'FI':>9} {'bound':>9} {'blend':>10} {'gap':>9}"
print(hdr); print("-" * len(hdr))
maxgap = 0.0
for (m, n) in [(96, 64), (384, 256)]:
    W = layer_like(m, n, seed=m)
    prep = M.prepare_layer(W)                       # real function
    for strat in ("energy-only", "energy+gradient"):
        g = np.random.default_rng(42).standard_normal(W.shape) * 0.01
        for tau in (0.7, 0.85, 0.95):
            d = M.analyze_layer("test", prep, strat, tau, g)   # real function
            maxgap = max(maxgap, d["fi_bound_gap"])
            print(f"{str(m)+'x'+str(n):>12} {strat:>16} {tau:>8} {d['density']*100:>8.2f}% "
                  f"{d['cr']:>6.2f}× {d['tau_ret']*100:>8.2f}% {d['fi_trunc']*100:>8.2f}% "
                  f"{d['fi_bound']*100:>8.2f}% {d['fi_blend']*100:>9.4f}% {d['fi_bound_gap']:>9.2e}")
print(f"\n=> theorem identity max deviation = {maxgap:.2e}  ({'PASS' if maxgap < 1e-10 else 'FAIL'})")

print()
print("=" * 92)
print("B) Across-seed (fake-gradient) dispersion -- quantify the uncertainty introduced by the current code's rng-based fake gradients")
print("=" * 92)
W = layer_like(384, 256, seed=7)
prep = M.prepare_layer(W)
for strat in ("energy-only", "energy+gradient"):
    fis, taus = [], []
    for sd in (1000, 1001, 1002, 1003, 1004):
        g = np.random.default_rng(sd).standard_normal(W.shape) * 0.01
        d = M.analyze_layer("t", prep, strat, 0.85, g)
        fis.append(d["fi_trunc"]); taus.append(d["tau_ret"])
    print(f"{strat:>16}: FI_honest = {np.mean(fis)*100:6.2f}% ± {np.std(fis)*100:5.2f}%   "
          f"tau_ret = {np.mean(taus)*100:6.2f}% ± {np.std(taus)*100:5.2f}%"
          + ("   <- fake gradients make the result non-reproducible" if np.std(fis) > 0.01 else ""))

print()
print("=" * 92)
print("C) Reference line: GPTQ INT4 measured fidelity 36.47% -- at which operating points does our method win?")
print("=" * 92)
W = layer_like(384, 256, seed=11)
prep = M.prepare_layer(W)
g = np.random.default_rng(42).standard_normal(W.shape) * 0.01
target = 0.3647
need_tau_ret = 1 - (1 - target) ** 2
print(f"To beat GPTQ ({target*100:.2f}%), need tau_ret > 1-(1-F)^2 = {need_tau_ret*100:.2f}%")
best = None
for strat in ("energy-only", "energy+gradient"):
    for tau in (0.3, 0.5, 0.7, 0.85, 0.95, 0.99):
        d = M.analyze_layer("t", prep, strat, tau, g)
        win = d["fi_trunc"] > target
        print(f"  {strat:>16} tau={tau:<5} CR={d['cr']:>6.2f}×  FI={d['fi_trunc']*100:6.2f}%  "
              f"{'win vs GPTQ' if win else 'lose'}")
        if win and (best is None or d["cr"] > best[1]):
            best = (strat, d["cr"], d["fi_trunc"], tau)
if best:
    print(f"\n=> Best operating point: {best[0]} τ={best[3]} -> CR={best[1]:.2f}× @ FI={best[2]*100:.2f}%")
else:
    print("\n=> No operating point on these synthetic weights beats GPTQ's fidelity")
print("\n(Note: synthetic weights only validate the code path and math; real Qwen weights have a more concentrated spectrum, so CR will be better -- measure it on the server.)")
