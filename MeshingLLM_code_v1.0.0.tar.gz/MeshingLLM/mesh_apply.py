#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
mesh_apply.py — actually apply the meshing support to the model weights, producing a compressed model that transformers can load directly
================================================================================
The compression side of E2 (downstream task evaluation). Does three things:
  1) Read the original safetensors (including bf16) -> DCT -> support M_θ -> reconstruct W_D = IDCT(M_θ ⊙ F)
     (optional: quantize the retained coefficients to INT4)
  2) Write out a **standard HF model directory** (config/tokenizer copied as-is; non-target tensors copied byte-for-byte, preserving dtype)
  3) Report the measured F_W / CR_p / CR_s / M_ser, and optionally --verify against pareto_full.csv

Key self-check: for energy-only τ=0.85, F_W must equal 61.27% (consistent with P1). If it does not match, do not use the result.

Usage:
  python3 mesh_apply.py --model Qwen/Qwen2.5-1.5B --strategy energy-only --tau 0.60 \
      --out results/compressed/L2 --verify
  python3 mesh_apply.py --model Qwen/Qwen2.5-1.5B --strategy energy+gradient --tau 0.85 \
      --grads results/grads_en_electronics.npz --out results/compressed/AND_t085
  python3 mesh_apply.py --model-dir /tmp/fake_model_bf16 --strategy energy-only --tau 0.85 \
      --out /tmp/out_fake --self-test          # offline end-to-end self-test
"""
from __future__ import annotations
import argparse, csv, gzip, json, math, os, shutil, struct, sys, time
from pathlib import Path
import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
try:
    import measure_fidelity_parallel as MF              # reuse the bf16-aware reader
except Exception as e:                                  # noqa: BLE001
    raise SystemExit(f"[fatal] measure_fidelity_parallel.py is required in the same directory: {e}")

B_VAL, B_ORIG = 16, 16
KEEP_FILES = ("config.json", "generation_config.json", "tokenizer.json", "tokenizer_config.json",
              "vocab.json", "merges.txt", "special_tokens_map.json", "tokenizer.model")


# ============================================================ writing (with raw-byte passthrough)
def _bf16_bytes(a: np.ndarray) -> bytes:
    u = a.astype(np.float32).view(np.uint32)
    u = (u + np.uint32(0x8000)) & np.uint32(0xFFFF0000)
    return (u >> 16).astype(np.uint16).tobytes()


def encode(arr: np.ndarray, dt: str) -> bytes:
    if dt == "BF16":
        return _bf16_bytes(arr)
    if dt == "F16":
        return arr.astype(np.float16).tobytes()
    return arr.astype(np.float32).tobytes()


def decode(raw: bytes, dt: str, shape) -> np.ndarray:
    """Restore raw bytes to an array. BF16 is reinterpreted as float32 by **bit pattern** (not a numeric conversion!)."""
    if dt == "BF16":
        u = np.frombuffer(raw, dtype=np.dtype("<u2")).astype(np.uint32) << 16
        return u.view(np.float32).reshape(shape)
    m = {"F16": np.dtype("<f2"), "F32": np.dtype("<f4"),
         "I64": np.dtype("<i8"), "I32": np.dtype("<i4"), "U8": np.dtype("u1")}
    return np.frombuffer(raw, dtype=m.get(dt, np.dtype("<f4"))).reshape(shape)


def write_safetensors(path, entries):
    """entries: list of (name, dtype, shape, raw_bytes) -- already-encoded raw bytes, concatenated directly into the container."""
    hdr, off = {}, 0
    for n, dt, shp, raw in entries:
        hdr[n] = {"dtype": dt, "shape": list(shp), "data_offsets": [off, off + len(raw)]}
        off += len(raw)
    hb = json.dumps(hdr, separators=(",", ":")).encode("utf-8")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(struct.pack("<Q", len(hb)))
        f.write(hb)
        for _, _, _, raw in entries:
            f.write(raw)


# ============================================================ index overhead
def _leb128(v):
    out = bytearray()
    while True:
        b = v & 0x7F; v >>= 7
        out.append(b | (0x80 if v else 0))
        if not v:
            return bytes(out)


def index_bits(mask):
    idx = np.flatnonzero(mask.ravel())
    n = max(len(idx), 1)
    d = np.diff(np.concatenate(([-1], idx.astype(np.int64))))
    vb = b"".join(_leb128(int(x)) for x in d)
    bm = np.packbits(mask.ravel()).tobytes()
    return {"varint": 8.0 * len(vb) / n,
            "bitmap": 8.0 * len(bm) / n,
            "gzidx": 8.0 * min(len(gzip.compress(vb, 9)), len(gzip.compress(bm, 9))) / n}


# ============================================================ main flow
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="Qwen/Qwen2.5-1.5B")
    ap.add_argument("--model-dir", default=None)
    ap.add_argument("--strategy", default="energy-only", choices=["energy-only", "energy+gradient"])
    ap.add_argument("--tau", type=float, default=0.60)
    ap.add_argument("--topk-frac", type=float, default=0.25, help="gradient top-k fraction for AND")
    ap.add_argument("--grads", default=None, help="grads.npz produced by extract_domain_grads.py")
    ap.add_argument("--coeff-bits", type=int, default=16, choices=[16, 4])
    ap.add_argument("--idx-coding", default="gzidx", choices=["varint", "bitmap", "gzidx"])
    ap.add_argument("--out", required=True)
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--self-test", action="store_true")
    a = ap.parse_args()

    mdir = MF._resolve_model_dir(a.model, a.model_dir)
    print(f"[env] model dir = {mdir}  |  strategy={a.strategy} τ={a.tau} "
          f"coeff={a.coeff_bits}bit idx={a.idx_coding}")
    tensors = MF._scan_tensors(mdir)
    print(f"[scan] {len(tensors)} target 2D tensors")

    grads = {}
    if a.grads:
        z = np.load(a.grads, allow_pickle=True)
        grads = {k: z[k] for k in z.files if not k.startswith("__")}
        print(f"[grads] loaded {len(grads)} gradient tensors <- {a.grads}")
    elif a.strategy == "energy+gradient":
        raise SystemExit("[fatal] the AND strategy requires --grads (real domain gradients)."
                         "Using random gradients was the fatal bug of the draft and is never allowed.")

    from meshing import dct2d, idct2d, compute_profile, select_freq

    by_file = {}
    for nm, fp, shp in tensors:
        by_file.setdefault(fp, []).append(nm)

    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    for fn in KEEP_FILES:
        src = mdir / fn
        if src.is_file():
            shutil.copy2(src, out / fn)

    rows, tot_params, t0 = [], 0, time.time()

    for fp, names in by_file.items():
        hdr, base = MF._st_header(fp)
        raw_all = open(fp, "rb").read()
        entries = []
        for nm in names:
            W = MF._read_tensor(fp, nm)
            m, n = W.shape
            F = dct2d(W); E = F * F; Etot = max(float(E.sum()), 1e-300)
            Gamma = compute_profile(F)
            if a.strategy == "energy-only":
                mask = select_freq(Gamma, "energy-only", tau=a.tau)
            else:
                g = grads.get(nm)
                if g is None:
                    raise SystemExit(f"[fatal] grads.npz is missing {nm} (layer-name mismatch?)")
                mask = select_freq(Gamma, "energy+gradient", W=W,
                                   grad=np.asarray(g, dtype=np.float64),
                                   tau=a.tau, topk_frac=a.topk_frac)
            dens = float(mask.mean())
            tau_ret = float(E[mask].sum() / Etot)
            Fk = F * mask
            if a.coeff_bits == 4:
                am = np.abs(Fk).max(axis=1, keepdims=True)
                s = np.maximum(am, 1e-30) / 7.0
                Fk = np.round(Fk / s) * s * mask
            Wd = idct2d(Fk)
            nrm2 = float((W * W).sum())
            err2 = float(((W - Wd) ** 2).sum())
            fw = 1.0 - math.sqrt(err2 / max(nrm2, 1e-300))
            # measure once more after writing to disk (the bf16 rounding cost, honestly reported here)
            dt = hdr[nm]["dtype"]
            Wd_back = decode(encode(Wd, dt), dt, (m, n)).astype(np.float32) if dt == "BF16" \
                else Wd.astype(np.float32)
            fw_disk = 1.0 - math.sqrt(float(((W.astype(np.float32) - Wd_back) ** 2).sum())
                                      / max(nrm2, 1e-300))
            ib = index_bits(mask)
            bpp = dens * (a.coeff_bits + ib[a.idx_coding]) + 16.0 / W.size
            rows.append({"layer": nm, "shape": [m, n], "dtype": dt, "density": dens,
                         "tau_ret": tau_ret, "F_W": fw, "F_W_on_disk": fw_disk,
                         "b_idx": ib[a.idx_coding], "bpp": bpp,
                         "CR_p": 1.0 / max(dens, 1e-12), "CR_s": B_ORIG / bpp})
            tot_params += W.size
            entries.append((nm, dt, (m, n), encode(Wd, dt)))
        for n in hdr:
            if n == "__metadata__" or n in names:
                continue
            info = hdr[n]
            b, e = info["data_offsets"]
            entries.append((n, info["dtype"], tuple(info["shape"]), raw_all[base + b: base + e]))
        outf = out / Path(fp).name
        write_safetensors(str(outf), entries)
        print(f"  {outf.name}: reconstructed {len(names)} + passed through {len(entries)-len(names)} tensors")

    mean = lambda k: float(np.mean([r[k] for r in rows]))
    crp, crs, rho = mean("CR_p"), mean("CR_s"), mean("density")
    fw_l, fw_m = mean("F_W"), mean("F_W_on_disk")
    m_ser = tot_params * B_ORIG / crs / 8 / 1e9
    summary = {"strategy": a.strategy, "tau": a.tau, "coeff_bits": a.coeff_bits,
               "idx_coding": a.idx_coding, "topk_frac": a.topk_frac,
               "n_layers": len(rows), "n_params": int(tot_params),
               "density_mean": rho, "CR_p_mean": crp, "CR_s_mean": crs,
               "F_W_layer_mean": fw_l, "F_W_on_disk_mean": fw_m,
               "tau_ret_mean": mean("tau_ret"), "b_idx_mean": mean("b_idx"),
               "M_ser_GB": m_ser, "elapsed_sec": round(time.time() - t0, 1), "out_dir": str(out)}
    with open(out / "mesh_report.json", "w", encoding="utf-8") as f:
        json.dump({"summary": summary, "per_layer": rows}, f, indent=2, ensure_ascii=False)

    print("=" * 92)
    print(f"layers {len(rows)} | ρ={100*rho:.2f}% | CR_p={crp:.2f}× | CR_s={crs:.2f}× | "
          f"b_idx={summary['b_idx_mean']:.2f} bit")
    print(f"F_W layer-mean(f64)={100*fw_l:.2f}% | after write(bf16)={100*fw_m:.2f}% | "
          f"τ_ret={100*summary['tau_ret_mean']:.2f}% | M_ser={m_ser:.3f} GB")
    print("=" * 92)
    print("report ->", out / "mesh_report.json")

    if a.verify:
        cand = [SCRIPT_DIR / "pareto_full.csv", Path("pareto_full.csv"),
                Path("results/fidelity_parallel/pareto_full.csv")]
        ref = next((c for c in cand if c.is_file()), None)
        if ref is None:
            print("[verify] pareto_full.csv not found, skipping")
        else:
            for r in csv.DictReader(open(ref, encoding="utf-8")):
                if r["strategy"] == a.strategy and abs(float(r["tau"]) - a.tau) < 1e-9:
                    key = "F_W_mean" if "F_W_mean" in r else "F_W_layer_mean"
                    exp = float(r[key]) * 100
                    got = fw_l * 100
                    print(f"[verify] reference {exp:.2f}%  vs  current {got:.2f}%  ->  "
                          f"{'consistent (pipeline correct)' if abs(exp-got) < 0.05 else 'inconsistent, result unusable!'}")
                    break


if __name__ == "__main__":
    main()
