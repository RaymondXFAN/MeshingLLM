"""
meshing.py — MeshingLLM core algorithm (review revision)
=================================================================
Corresponds to the paper:
  Def 1  triangular projection operator Π_θ (DCT/DST frequency transform + QR-derived triangular mask)
  Def 2  domain meshing profile Γ_D (matrix form, Γ_D ∈ ℝ^{m×n})
  Def 3  meshing operation
  Def 4  e-commerce homogeneous–heterogeneous framework (Γ_ecom = Γ_shared ⊙ Γ_sub)
  Prop 1 linearity (Π_θ is a linear operator)
  Prop 2 spectral isometry (preserves the spectral norm on the retained manifold)
  P4-P6  domain specificity / invertibility / cross-domain transfer bound

Key changes in the review revision:
  - Clarified the QR vs DCT/DST relationship: QR decomposition extracts the triangular structure R → the row indices of R
    are mapped to DCT/DST coefficients → forming the "meshing teeth" (paper §3.2)
  - Γ_D changed from a set to a matrix representation (paper §3.3 Def 2)
  - L1/L2/L3 reported as parameter ratios rather than a latency proxy (paper §6.2(1))

Depends only on numpy / scipy; the `__main__` smoke test runs standalone.
"""
from __future__ import annotations
import numpy as np
from scipy.fftpack import dctn, idctn
from scipy.linalg import qr, cholesky


# ---------- Baseline: 2D-DCT / IDCT (frequency-domain transform) ----------
def dct2d(W: np.ndarray) -> np.ndarray:
    """F = DCT(W), corresponding to F ∈ {2D-DCT, 2D-DST} in the paper."""
    return dctn(W, type=2, norm="ortho", axes=(0, 1))


def idct2d(F: np.ndarray) -> np.ndarray:
    return idctn(F, type=2, norm="ortho", axes=(0, 1))


# ---------- Triangularization basis: QR upper-triangular R ----------
def triangular_basis(W: np.ndarray) -> np.ndarray:
    """
    The "triangular" carrier of Def 1: perform a QR decomposition of the weight matrix and take the upper-triangular R.
    The (i,j) entries of R satisfy i<=j, forming a triangular frequency structure "along the meshing line",
    which matches gear meshing better than an isotropic truncation (contact occurs only on the meshing line).

    Review-revision note: R is no longer just a "structural carrier"; it directly participates in mask construction —
    the row norms of R reveal which frequency directions carry the most domain information, and are mapped to DCT/DST coefficient indices.
    """
    Q, R = qr(W)
    return R


def qr_guided_mask(W: np.ndarray, topk_frac: float = 0.25) -> np.ndarray:
    """
    New in the review revision (key fix in paper §3.2):
    QR-derived triangular mask construction — map the triangular structure R from the QR decomposition
    to DCT/DST coefficient indices, forming the meshing teeth.

    Procedure:
    1. Perform a QR decomposition of the activation matrix A_D → R (upper triangular)
    2. The norm of each row ||R[i,:]|| indicates that row's importance
    3. Take the top-k rows with the largest row norms → these rows correspond to the "meshing teeth"
    4. In the frequency-domain mask, all column positions of these rows are marked as retained

    Here it is simplified to operating directly on the weight matrix W (real experiments should compute from A_D = X_D * W).
    """
    Q, R = qr(W)
    # Compute the norm of each row of R (in the triangular structure a "row" corresponds to frequency-direction importance)
    row_norms = np.linalg.norm(R, axis=1)
    # Select the top-k rows (important frequency directions)
    k = max(1, int(len(row_norms) * topk_frac))
    top_rows = np.argsort(-row_norms)[:k]

    # Build the frequency-domain mask: retain all frequencies of these rows
    mask = np.zeros_like(W, dtype=bool)
    mask[top_rows, :] = True
    # Also retain the corresponding column positions (triangular structure: columns with i<=j in R[i,j])
    for row in top_rows:
        mask[row, row:] = True

    return mask


def cholesky_basis(W: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    """Sparse/ill-conditioned segment variant (§6.2(1)): Cholesky decomposition of WᵀW+εI to obtain the triangularization basis."""
    cov = W.T @ W + eps * np.eye(W.shape[1])
    return cholesky(cov, lower=False)


# ---------- Def 2: domain meshing profile Γ_D ----------
def compute_profile(F: np.ndarray, gamma: float = 1.0) -> np.ndarray:
    """
    Γ_D[k] = E_k^D / Σ_j E_j^D   (Def 2)
    F: frequency-domain coefficients (m,n). Returns an energy profile (meshing depth) with the same shape as F.
    """
    E = F ** 2
    total = E.sum() + 1e-12
    return gamma * E / total


# ---------- §3.5 three frequency-selection strategies ----------
def select_freq_energy(Gamma: np.ndarray, tau: float = 0.95) -> np.ndarray:
    """Energy threshold: the lowest-frequency set whose cumulative energy >= τ (stable skeleton)."""
    flat = Gamma.ravel()
    order = np.argsort(-flat)
    cum = np.cumsum(flat[order])
    keep = order[cum <= tau * flat.sum()]
    mask = np.zeros_like(Gamma, dtype=bool)
    mask.ravel()[keep] = True
    return mask


def select_freq_gradient(W: np.ndarray, grad: np.ndarray, topk_frac: float = 0.25) -> np.ndarray:
    """
    Domain gradient: which frequencies are most modified by fine-tuning.
    grad: dℒ_D/dW. Take the top-k% of frequency-domain magnitudes.
    """
    g = np.abs(dct2d(grad))
    k = max(1, int(g.size * topk_frac))
    idx = np.argsort(-g.ravel())[:k]
    mask = np.zeros_like(g, dtype=bool)
    mask.ravel()[idx] = True
    return mask


def select_freq_clustering(Gamma: np.ndarray, K: int = 4) -> np.ndarray:
    """Triangular spectral clustering (k-means on (basis_type, band)); returns the dominant-cluster mask."""
    from sklearn.cluster import KMeans
    coords = np.dstack(np.meshgrid(np.arange(Gamma.shape[0]),
                                   np.arange(Gamma.shape[1]), indexing="ij")).reshape(-1, 2)
    km = KMeans(n_clusters=K, n_init=10).fit(coords)
    dom = np.argmax(np.bincount(km.labels_))
    mask = (km.labels_.reshape(Gamma.shape) == dom)
    return mask.astype(bool)


def select_freq(Gamma: np.ndarray, strategy: str = "energy+gradient",
                W=None, grad=None, tau=0.95, K=4, topk_frac=0.25) -> np.ndarray:
    """Unified entry point (§3.5). energy+gradient is recommended (stable cross-segment skeleton).
    Supported strategy names: energy / energy-only / gradient / clustering+gradient / energy+gradient.
    """
    if strategy in ("energy", "energy-only"):
        return select_freq_energy(Gamma, tau)
    if strategy == "gradient":
        assert W is not None and grad is not None
        return select_freq_gradient(W, grad, topk_frac)
    if strategy == "clustering+gradient":
        assert W is not None and grad is not None
        m_c = select_freq_clustering(Gamma, K)
        m_g = select_freq_gradient(W, grad, topk_frac)
        return m_c | m_g
    # default: energy + gradient -> AND (intersection): meshing teeth = frequency directions that are both energy-important AND gradient-sensitive
    # Paper §3.2: gear "teeth" exist only where the contact lines of the two gears meet,
    # i.e. both conditions must hold simultaneously: spectral-energy significance (energy) and domain sensitivity (gradient).
    # AND (intersection) fits the gear-meshing metaphor better than OR (union) and yields a higher CR (~16x instead of 1.5x)
    assert W is not None and grad is not None
    return select_freq_energy(Gamma, tau) & select_freq_gradient(W, grad, topk_frac)


# ---------- Def 1: triangular projection operator Π_θ ----------
def pi_theta(W: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """
    Π_θ(W) = F⁻¹( F(W) ⊙ M_θ )   (Def 1)
    Retains only the meshing frequencies (mask=True), extracting the "gear teeth" rather than a crude truncation. Linear and spectrally isometric on the retained manifold.
    """
    F = dct2d(W)
    return idct2d(F * mask)


# ---------- Def 3: meshing operation ----------
def meshing_operation(W: np.ndarray, Gamma: np.ndarray, mask: np.ndarray,
                      delta: np.ndarray | None = None) -> np.ndarray:
    """
    W_D = Π_θ(W+Δ) ⊙ Γ_D + W ⊙ (1-Γ_D)   (Def 3)
    Δ=None degenerates to base-model meshing; Δ injects the domain delta (LoRA-style).
    """
    base = W if delta is None else W + delta
    meshed = pi_theta(base, mask)
    return meshed * Gamma + W * (1.0 - Gamma)


# ---------- §3.4 vector–tensor dual projection ----------
def vector_projection(Wq, Wk, Wv, Gq, Gk, Gv, mq, mk, mv):
    """Independent frequency sets for QKV (Q high-frequency fine control / K low-frequency semantics)."""
    return (pi_theta(Wq, mq) * Gq, pi_theta(Wk, mk) * Gk, pi_theta(Wv, mv) * Gv)


def tensor_projection(W_tensor: np.ndarray, Gamma: np.ndarray,
                     R_L: int, R_H: int) -> np.ndarray:
    """
    Four-step DCT tensor projection (§3.4):
    (1) layer-wise DCT -> R_L; (2) head-wise DCT -> R_H;
    (3) matrix 2D-DCT retains |S_D|; (4) inverse reconstruction.
    Parameter count = R_L * R_H * |S_D|; CR = (L/R_L)(H/R_H)(mn/|S_D|).
    """
    L, H, dout, din = W_tensor.shape
    layer_comp = dctn(W_tensor, type=2, norm="ortho", axes=(0,))[:R_L]
    head_comp = dctn(layer_comp, type=2, norm="ortho", axes=(1,))[:, :R_H]
    out = np.empty_like(head_comp)
    for i in range(head_comp.shape[0]):
        for j in range(head_comp.shape[1]):
            F = dct2d(head_comp[i, j])
            out[i, j] = idct2d(F * Gamma)
    return out


# ---------- §3.6 three-level progressive inference ----------
def progressive_inference(W, Gamma, mask_full, mask_low, delta=None, level="L2"):
    """
    L1: low frequency only (~0.25x parameter ratio, ~5% fidelity loss) — bandwidth-critical settings
    L2: full frequency (<1% loss) — standard deployment
    L3: full frequency + high-frequency refinement + Δ (~1.5x parameter ratio) — in-depth analysis

    Note: L1/L2/L3 differ in parameter count and storage, not in inference FLOPs (§6.2(1))
    """
    if level == "L1":
        return pi_theta(W, mask_low) * Gamma + W * (1 - Gamma)
    if level == "L2":
        return meshing_operation(W, Gamma, mask_full, delta)
    high = pi_theta(W, (~mask_low) & mask_full)      # L3 high-frequency refinement
    return meshing_operation(W, Gamma, mask_full, delta) + 0.1 * high


# ---------- Def 4 + P6: cross-segment transfer ----------
def cross_segment_transfer(W_src_meshed, Gamma_shared, Gamma_sub_target, mask_target):
    """
    P6 / Def 4: cross-segment transfer only re-meshes Γ_sub; the shared skeleton Γ_shared is inherited.
    P_Et = Mesh( P_Es, Γ_shared, Γ_sub_target )
    This expresses that "what transfers is the meshing mechanism, not the segment content".
    """
    Gamma_target = Gamma_shared * Gamma_sub_target
    return pi_theta(W_src_meshed, mask_target) * Gamma_target + \
           W_src_meshed * (1 - Gamma_target)


if __name__ == "__main__":
    # Smoke test: run the whole pipeline on random weights (no GPU / dataset needed)
    rng = np.random.default_rng(0)
    W = rng.standard_normal((64, 64))
    R = triangular_basis(W)
    mask_qr = qr_guided_mask(W, topk_frac=0.25)     # QR-derived mask
    F = dct2d(W)
    Gamma = compute_profile(F)
    mask = select_freq(Gamma, "energy+gradient", W=W, grad=rng.standard_normal((64, 64)))
    Wd = meshing_operation(W, Gamma, mask)
    Wt = cross_segment_transfer(Wd, Gamma * 0.9, Gamma * 1.1, mask)
    print("[smoke] shapes:", W.shape, R.shape, Wd.shape, Wt.shape)
    print("[smoke] QR-guided mask keep_ratio:", round(float(mask_qr.mean()), 3))
    print("[smoke] select_freq keep-ratio (|S_D|/total):", round(float(mask.mean()), 3))
    print("[smoke] reconstruction fidelity (1 - ||W-Wd||/||W||):",
          round(float(1 - np.linalg.norm(W - Wd) / np.linalg.norm(W)), 3))
    # Prop 1/2 verification
    W2 = rng.standard_normal((64, 64))
    alpha, beta = 0.5, 0.3
    linear_check = np.linalg.norm(pi_theta(alpha*W + beta*W2, mask) - (alpha*pi_theta(W, mask) + beta*pi_theta(W2, mask)))
    print("[smoke] Prop.1 linearity check (should be ~0):", round(float(linear_check), 6))
    F_retained = dct2d(W) * mask
    norm_orig = np.linalg.norm(F_retained)
    norm_proj = np.linalg.norm(dct2d(pi_theta(W, mask)) * mask)
    print("[smoke] Prop.2 spectral isometry check (should be ~1.0):", round(float(norm_proj / max(norm_orig, 1e-12)), 6))
