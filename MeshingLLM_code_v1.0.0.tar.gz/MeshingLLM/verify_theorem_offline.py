#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify_theorem_offline.py — offline verification (no model / GPU / data required)
Verifies two things:
  (1) Theorem identity: FI_trunc == 1 - sqrt(1 - tau_ret)   (pure truncation; DCT orthogonality ⟹ exact)
  (2) Why the current paper metric is inflated: FI_blend ~ 1 (because ΣΓ_D = 1)
Run: python3 verify_theorem_offline.py
"""
import sys, math
from pathlib import Path
import numpy as np

BK = Path("/sandbox/workspace/ICEBE2026_MeshingLLM_backup/06_code")
sys.path.insert(0, str(BK))
from meshing import dct2d, compute_profile, select_freq, pi_theta

rng = np.random.default_rng(0)

def layer_like(m, n, scale=0.02, lowrank=8, seed=0):
    """Build a weight-like matrix: low-rank skeleton + noise (closer to the spectral decay of real LLM weights)"""
    r = np.random.default_rng(seed)
    U = r.standard_normal((m, lowrank)); V = r.standard_normal((lowrank, n))
    return (scale * (U @ V) + 0.3 * scale * r.standard_normal((m, n))).astype(np.float64)

print("=" * 84)
print("[Check 1] Theorem identity  FI_trunc = 1 - sqrt(1 - tau_ret)   (pure truncation)")
print("=" * 84)
print(f"{'shape':>14} {'strategy':>16} {'tau_set':>8} {'tau_ret':>9} {'FI_trunc':>10} {'FI_bound':>10} {'|gap|':>10}")
ok_all = True
for (m, n) in [(64, 64), (256, 128), (512, 384)]:
    W = layer_like(m, n, seed=m)
    for strategy in ["energy-only", "energy+gradient"]:
        F = dct2d(W); E = F * F; Etot = E.sum()
        Gamma = compute_profile(F)
        grad = rng.standard_normal(W.shape) * 0.01
        for tau in [0.5, 0.85, 0.95, 0.99]:
            mask = select_freq(Gamma, strategy, W=W, grad=grad, tau=tau)
            tau_ret = float(E[mask].sum() / Etot)
            Wd = pi_theta(W, mask)
            fi_t = 1.0 - np.linalg.norm(W - Wd) / np.linalg.norm(W)
            fi_b = 1.0 - math.sqrt(max(1.0 - tau_ret, 0.0))
            gap = abs(fi_t - fi_b)
            ok_all &= (gap < 1e-10)
            print(f"{str(m)+'x'+str(n):>14} {strategy:>16} {tau:>8} {tau_ret:>9.4f} "
                  f"{fi_t:>10.6f} {fi_b:>10.6f} {gap:>10.2e}")
print(f"\nIdentity holds in all cases (max deviation < 1e-10): {ok_all}")

print()
print("=" * 84)
print("[Check 2] Why the current paper metric FI_blend is inflated (Γ_D is an energy distribution, ΣΓ_D = 1)")
print("=" * 84)
W = layer_like(512, 384, seed=7)
F = dct2d(W); E = F * F; Etot = E.sum()
Gamma = compute_profile(F)
mask = select_freq(Gamma, "energy+gradient", W=W,
                   grad=rng.standard_normal(W.shape) * 0.01, tau=0.85)
tau_ret = float(E[mask].sum() / Etot)
Wd = pi_theta(W, mask)

fi_trunc = 1.0 - np.linalg.norm(W - Wd) / np.linalg.norm(W)
Wd_blend = Wd * Gamma + W * (1.0 - Gamma)
fi_blend = 1.0 - np.linalg.norm(W - Wd_blend) / np.linalg.norm(W)

print(f"ΣΓ_D            = {Gamma.sum():.10f}   ← always 1 (a probability distribution, not a selector)")
print(f"max Γ_D         = {Gamma.max():.3e}")
print(f"mean Γ_D        = {Gamma.mean():.3e}   ← magnitude 1/(m·n) = {1/(W.size):.3e}")
print(f"tau_ret         = {tau_ret*100:.3f}%")
print(f"(1) FI_trunc      = {fi_trunc*100:.4f}%   ← honest metric")
print(f"(3) FI_blend      = {fi_blend*100:.4f}%   ← current paper setting (inflated by {(fi_blend-fi_trunc)*100:.4f} percentage points)")
print(f"   relative-error amplification factor = {(1-fi_trunc)/max(1-fi_blend,1e-12):.1f}× erased by Γ_D")
print()
print("Conclusion: as a mixing coefficient Γ_D has γ_k~1e-5, which scales down the whole (Π_θ(W)-W) error;")
print("   hence (3) necessarily approaches 100% regardless of the compression ratio — externally we must switch to (1).")

print()
print("=" * 84)
print("[Check 3] True dependence of the honest fidelity on CR (this is the curve the paper should report)")
print("=" * 84)
print(f"{'strategy':>16} {'tau_set':>8} {'density':>9} {'CR':>8} {'tau_ret':>9} {'FI_trunc':>10}")
F = dct2d(W); E = F * F; Etot = E.sum()
Gamma = compute_profile(F)
grad = rng.standard_normal(W.shape) * 0.01
for strategy in ["energy-only", "energy+gradient"]:
    for tau in [0.5, 0.7, 0.85, 0.9, 0.95, 0.99]:
        mask = select_freq(Gamma, strategy, W=W, grad=grad, tau=tau)
        dens = float(mask.mean()); tau_ret = float(E[mask].sum() / Etot)
        Wd = pi_theta(W, mask)
        fi = 1.0 - np.linalg.norm(W - Wd) / np.linalg.norm(W)
        print(f"{strategy:>16} {tau:>8} {dens*100:>8.2f}% {1/max(dens,1e-12):>7.2f}× "
              f"{tau_ret*100:>8.2f}% {fi*100:>9.2f}%")
