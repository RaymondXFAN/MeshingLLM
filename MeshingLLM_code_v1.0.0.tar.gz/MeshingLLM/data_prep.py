"""data_prep.py — download datasets and slice them (review revision: 4 core datasets).

2026-07-31 update: HF dataset structure changed; adapted to actually available sources:
  1. FinanceBench has only a train split (150 rows), no test -> split manually
  2. The original Amazon Reviews dataset (keung2019multilingual) is deprecated
     -> switched to srvmishra832/multilingual-amazon-reviews-6-languages (1.2M rows, 6 languages)
  3. The original SHOPPING Intent dataset (tasksource) no longer exists
     -> switched to jtlicardo/ecommerce-intent-6k (6000 e-commerce intent classification rows)

The slices are written as JSONL files under data/<segment>/,
ready for direct use by train_eval.py and the cross-segment transfer experiments.

Before running you must set the HF mirror (required in mainland China):
  Windows: set HF_ENDPOINT=https://hf-mirror.com
  Linux/Mac: export HF_ENDPOINT=https://hf-mirror.com
"""
from __future__ import annotations
import json
from pathlib import Path
from datasets import load_dataset
from config import Config


def prep_financebench(cfg: Config):
    """Download FinanceBench (public version, ~150 financial QA items).

    FinanceBench has only a train split, no test. Here we split it manually 80/20.
    The paper labels it "FinanceBench (150 financial QA, public subset)".
    """
    print("[financebench] downloading ...")
    ds = load_dataset(cfg.financebench, split="train")
    print(f"[financebench] raw rows: {len(ds)}")

    out = Path(cfg.data_root) / "financebench"
    out.mkdir(parents=True, exist_ok=True)

    # manual 80/20 split (because there is no test split on HF)
    split = ds.train_test_split(test_size=0.2, seed=42)
    split["train"].to_json(str(out / "train.jsonl"))
    split["test"].to_json(str(out / "test.jsonl"))
    print(f"[financebench] train:{len(split['train'])} test:{len(split['test'])}")
    print(f"[financebench] -> {out}")


def prep_mmlu(cfg: Config):
    """Download the MMLU-Accounting subset (well-formed, has a test split)."""
    out = Path(cfg.data_root) / "mmlu_business"
    out.mkdir(parents=True, exist_ok=True)
    for sub in cfg.mmlu_business_subsets:
        print(f"[mmlu] downloading {sub} ...")
        d = load_dataset("cais/mmlu", sub, split="test")
        d.to_json(str(out / f"{sub}.jsonl"))
        print(f"[mmlu] {sub} -> {out / (sub + '.jsonl')}  ({len(d)} rows)")


def slice_amazon(cfg: Config):
    """Download the multilingual Amazon Reviews and slice by category and region.

    Source: srvmishra832/multilingual-amazon-reviews-6-languages
    This dataset has 1.2M rows, 6 languages (de/en/es/fr/ja/zh) and 28 categories.
    Columns: review_id, product_id, reviewer_id, stars, review_body,
          review_title, language, product_category

    Category slice: Electronics vs Home_Improvement -> category heterogeneity
    Region slice: en (US/EU) vs zh (Chinese) -> region heterogeneity
    """
    print("[amazon] downloading (1.2M rows, may take a few minutes) ...")
    ds = load_dataset(cfg.amazon_reviews, split="train")
    print(f"[amazon] raw rows: {len(ds)}")

    out = Path(cfg.data_root) / "amazon"
    out.mkdir(parents=True, exist_ok=True)

    for lang in ("en", "zh"):
        print(f"[amazon] filtering by language={lang} ...")
        lang_ds = ds.filter(lambda x: x["language"] == lang)
        if len(lang_ds) == 0:
            print(f"[amazon] {lang}: 0 rows, skip")
            continue

        # save the full language data
        lang_dir = out / lang
        lang_dir.mkdir(parents=True, exist_ok=True)
        lang_ds.to_json(str(lang_dir / "all.jsonl"))
        print(f"[amazon:{lang}] full -> {lang_dir / 'all.jsonl'}  ({len(lang_ds)} rows)")

        # category slice (keep only electronics and home_improvement)
        for cat in ("electronics", "home_improvement"):
            cat_ds = lang_ds.filter(lambda x: x["product_category"] == cat)
            if len(cat_ds) > 0:
                cat_dir = out / f"{lang}_{cat}"
                cat_dir.mkdir(parents=True, exist_ok=True)
                split = cat_ds.train_test_split(test_size=0.2, seed=42)
                split["train"].to_json(str(cat_dir / "train.jsonl"))
                split["test"].to_json(str(cat_dir / "test.jsonl"))
                print(f"[amazon:{lang}_{cat}] train:{len(split['train'])} test:{len(split['test'])}")
            else:
                print(f"[amazon:{lang}_{cat}] 0 rows, skip")


def prep_shopping(cfg: Config):
    """Download the e-commerce intent classification dataset (jtlicardo/ecommerce-intent-6k).

    Replaces the original tasksource/Shopping-Queries-Dataset (no longer exists).
    This dataset has 6000 rows; columns: prompt, completion, language.
    Use the English subset for intent-classification evaluation.
    """
    print("[shopping] downloading ...")
    out = Path(cfg.data_root) / "shopping_intent"
    out.mkdir(parents=True, exist_ok=True)

    try:
        ds = load_dataset(cfg.shopping_intent, split="train")
        print(f"[shopping] raw rows: {len(ds)}, columns: {ds.column_names}")

        # take the English subset (the language field may be "english")
        en_ds = ds.filter(lambda x: x.get("language", "english").lower() == "english")
        if len(en_ds) == 0:
            # if the language field is missing or all English, use the full data
            en_ds = ds
            print("[shopping] no language filter, using the full data")

        # cap the row count for the conference version (<=5000)
        if len(en_ds) > 5000:
            en_ds = en_ds.shuffle(seed=42).select(range(5000))

        # 80/20 split
        split = en_ds.train_test_split(test_size=0.2, seed=42)
        split["train"].to_json(str(out / "train.jsonl"))
        split["test"].to_json(str(out / "test.jsonl"))
        print(f"[shopping] train:{len(split['train'])} test:{len(split['test'])}")

    except Exception as e:
        print(f"[shopping] download failed: {e}")
        print("[shopping] please search for the 'ecommerce intent' dataset and download it manually")
        # create an empty placeholder file to avoid errors in downstream steps
        placeholder = [{"placeholder": True, "text": "fill in manually"}]
        with open(out / "train.jsonl", "w") as f:
            for item in placeholder:
                f.write(json.dumps(item) + "\n")
        with open(out / "test.jsonl", "w") as f:
            for item in placeholder:
                f.write(json.dumps(item) + "\n")
        print(f"[shopping] created placeholder file -> {out}")


def main():
    cfg = Config()
    print("=" * 50)
    print("MeshingLLM data preparation (review revision: 4 datasets)")
    print("Before running you must set the HF mirror:")
    print("   Windows: set HF_ENDPOINT=https://hf-mirror.com")
    print("   Linux/Mac: export HF_ENDPOINT=https://hf-mirror.com")
    print("=" * 50)

    prep_financebench(cfg)
    prep_mmlu(cfg)
    slice_amazon(cfg)
    prep_shopping(cfg)

    print("\n" + "=" * 50)
    print("Data preparation complete!")
    print("Please check that the subdirectories under data/ contain JSONL files.")
    print("=" * 50)


if __name__ == "__main__":
    main()
