#!/usr/bin/env bash
# =============================================================================
# fetch_model.sh — robust Qwen model download (AutoDL / mainland China network)
# -----------------------------------------------------------------------------
# Usage (in a server terminal):
#   bash fetch_model.sh                                        # default Qwen/Qwen2.5-1.5B
#   bash fetch_model.sh Qwen/Qwen2.5-7B                        # specify the model
#   bash fetch_model.sh Qwen/Qwen2.5-1.5B /root/autodl-tmp/models/Qwen2.5-1.5B
#
# Strategy: 1) enable AutoDL academic acceleration -> 2) HF mirror (hf-mirror) -> 3) fall back to ModelScope on failure
# =============================================================================
set -uo pipefail
[ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ] && { sed -n '2,12p' "$0"; exit 0; }

MODEL="${1:-Qwen/Qwen2.5-1.5B}"
DEST="${2:-/root/autodl-tmp/models/$(basename "$MODEL")}"
mkdir -p "$DEST"

echo "=============================================================="
echo " model : $MODEL"
echo " dest  : $DEST"
echo "=============================================================="

echo
echo "[1/4] enable AutoDL academic acceleration"
if [ -f /etc/network_turbo ]; then
  # shellcheck disable=SC1091
  source /etc/network_turbo && echo "  enabled" || echo "  (enable failed, continuing)"
else
  echo "  (no /etc/network_turbo, skipping)"
fi
export HF_ENDPOINT=https://hf-mirror.com
echo "  HF_ENDPOINT=$HF_ENDPOINT"

echo
echo "[2/4] trying HuggingFace mirror download ..."
if command -v hf >/dev/null 2>&1; then
  hf download "$MODEL" --local-dir "$DEST" || echo "  (hf download failed)"
elif command -v huggingface-cli >/dev/null 2>&1; then
  huggingface-cli download "$MODEL" --local-dir "$DEST" || echo "  (huggingface-cli download failed)"
else
  python3 - "$MODEL" "$DEST" <<'PYEOF' || echo "  (huggingface_hub download failed)"
import os, sys
os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
from huggingface_hub import snapshot_download
print("Downloaded to:", snapshot_download(sys.argv[1], local_dir=sys.argv[2]))
PYEOF
fi

if [ ! -f "$DEST/config.json" ]; then
  echo
  echo "[3/4] HF route failed -> switching to ModelScope (most reliable in mainland China) ..."
  pip install -q -U modelscope -i https://pypi.tuna.tsinghua.edu.cn/simple 2>/dev/null \
    || pip install -q -U modelscope || true
  python3 - "$MODEL" <<'PYEOF' || echo "  (ModelScope also failed)"
import sys
from modelscope import snapshot_download
print("ModelScope downloaded to:", snapshot_download(sys.argv[1], cache_dir="/root/autodl-tmp/models"))
PYEOF
fi

# ModelScope may download to cache_dir/<owner>/<name>; locate the real directory
if [ ! -f "$DEST/config.json" ]; then
  CAND=$(find /root/autodl-tmp/models -maxdepth 4 -name config.json -path "*$(basename "$MODEL")*" 2>/dev/null | head -1)
  [ -n "$CAND" ] && DEST=$(dirname "$CAND") && echo "  -> actual model dir: $DEST"
fi

echo
echo "[4/4] verify"
if [ -f "$DEST/config.json" ]; then
  echo "  model ready: $DEST"
  du -sh "$DEST" 2>/dev/null || true
  echo
  echo "  Next (run P1 offline, no network at all):"
  echo "    cd /root/autodl-tmp/MeshingLLM"
  echo "    CUDA_VISIBLE_DEVICES=\"\" python3 measure_fidelity_honest.py \\"
  echo "      --model $DEST --offline --strategy energy-only --tau 0.85 --tau-sweep"
else
  echo "  config.json not found; model not ready"
  echo "  Manual troubleshooting:"
  echo "    ls -l \"$DEST\""
  echo "    curl -I https://hf-mirror.com"
  exit 1
fi
