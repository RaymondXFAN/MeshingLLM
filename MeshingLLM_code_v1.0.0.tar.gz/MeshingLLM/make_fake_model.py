#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""make_fake_model.py — build a safetensors fake model with **real dtypes** (bf16/fp16/fp32), for offline self-testing."""
import json, struct, os, sys
import numpy as np

OUT = sys.argv[1] if len(sys.argv) > 1 else "/tmp/fake_model_bf16"
os.makedirs(OUT, exist_ok=True)


def bf16_bytes(a):
    u = a.astype(np.float32).view(np.uint32)
    u = (u + np.uint32(0x8000)) & np.uint32(0xFFFF0000)
    return (u >> 16).astype(np.uint16).tobytes()


def write_st(path, tensors):
    header, blobs, off = {}, [], 0
    for name, (arr, dt) in tensors.items():
        raw = bf16_bytes(arr) if dt == "BF16" else (
            arr.astype(np.float32).tobytes() if dt == "F32" else arr.astype(np.float16).tobytes())
        header[name] = {"dtype": dt, "shape": list(arr.shape),
                        "data_offsets": [off, off + len(raw)]}
        blobs.append(raw); off += len(raw)
    hb = json.dumps(header).encode("utf-8")
    with open(path, "wb") as f:
        f.write(struct.pack("<Q", len(hb))); f.write(hb)
        for b in blobs:
            f.write(b)


rng = np.random.default_rng(0)
t = {}
for L in (0, 1):
    t[f"model.layers.{L}.self_attn.q_proj.weight"] = (rng.standard_normal((64, 48)) * 0.05, "BF16")
    t[f"model.layers.{L}.self_attn.o_proj.weight"] = (rng.standard_normal((48, 64)) * 0.05, "BF16")
    t[f"model.layers.{L}.mlp.down_proj.weight"] = (rng.standard_normal((48, 128)) * 0.05, "BF16")
    t[f"model.layers.{L}.mlp.up_proj.weight"] = (rng.standard_normal((128, 48)) * 0.05, "F32")
    t[f"model.layers.{L}.mlp.gate_proj.weight"] = (rng.standard_normal((128, 48)) * 0.05, "F16")
    t[f"model.layers.{L}.self_attn.q_proj.bias"] = (rng.standard_normal((48,)), "BF16")
t["model.embed_tokens.weight"] = (rng.standard_normal((64, 32)), "BF16")

write_st(os.path.join(OUT, "model-00001-of-00001.safetensors"), t)
n2 = sum(1 for k, (a, d) in t.items() if a.ndim == 2 and any(
    s in k for s in ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")))
print(f"[ok] fake model written to {OUT}: {n2} 2D target tensors, {len(t)} entries total")
