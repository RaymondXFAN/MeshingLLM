#!/usr/bin/env bash
# =============================================================================
# check.sh — P1 progress view (non-blocking: returns immediately; it will never hang and force you to press Ctrl+C)
# -----------------------------------------------------------------------------
# Usage (one line):
#   cd /root/autodl-tmp/MeshingLLM && bash check.sh
# =============================================================================
set -uo pipefail
cd "$(dirname "$0")"

echo "$(date '+%F %T')"
echo

echo "========== 1) running processes =========="
# Only recognize processes whose comm is python* (to avoid counting a shell whose command line merely contains that string)
FOUND=""
for pid in $(pgrep -f "measure_fidelity_honest\.py" 2>/dev/null); do
  comm=$(ps -o comm= -p "$pid" 2>/dev/null | tr -d ' ')
  case "$comm" in
    python|python3|python3.*|python3.[0-9]*)
      etime=$(ps -o etime= -p "$pid" 2>/dev/null | tr -d ' ')
      echo "  PID $pid  running for $etime"
      FOUND=1 ;;
  esac
done
if [ -n "$FOUND" ]; then
  echo "  -> a measurement task is running"
else
  echo "  (no measure_fidelity_honest.py process)"
fi
echo

echo "========== 2) latest log (last 15 lines) =========="
for f in logs/p1_all.log logs/p1_energy_only.log logs/p1_boot.log; do
  if [ -f "$f" ]; then
    echo "--- $f  (size $(du -h "$f" | cut -f1), last updated $(date -r "$f" '+%H:%M:%S')) ---"
    tail -n 15 "$f"
    echo
  fi
done
echo

echo "========== 3) output files =========="
ls -lh results/fidelity_honest/ 2>/dev/null || echo "  (no output yet)"
echo

echo "========== 4) summary (if finished) =========="
if [ -f P1_SUMMARY.txt ]; then
  echo "P1_SUMMARY.txt generated (just cat P1_SUMMARY.txt to see the whole thing)"
  grep -E "FI_trunc|FI_bound|FI_blend|tau_ret_mean|density_mean|CR_mean|coverage_energy_frac|n_layers" P1_SUMMARY.txt | head -30
else
  echo "  (still running; P1_SUMMARY.txt not generated yet)"
fi
