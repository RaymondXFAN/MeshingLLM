#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eval_downstream.py — E2: downstream task evaluation (addressing R2-red1 / R3-(1))
================================================================================
Three e-commerce tasks, **one script evaluates all models** (dense / compressed / INT4), ensuring consistent accounting:
  ppl        domain perplexity = exp(mean LM loss) on held-out text
  sentiment  Amazon sentiment  = stars>=4 positive / <=2 negative; score completions and pick argmin-loss -> Acc / macro-F1
  intent     e-commerce intent classification = score candidate completions -> Acc / macro-F1

Usage (one line per configuration):
  # dense baseline
  python3 eval_downstream.py --model Qwen/Qwen2.5-1.5B --task ppl \
      --jsonl data/amazon/en_electronics/test.jsonl --out results/eval/ppl_dense_elec.json
  # compressed model (directory produced by mesh_apply.py)
  python3 eval_downstream.py --model results/compressed/L2 --task ppl \
      --jsonl data/amazon/en_electronics/test.jsonl --out results/eval/ppl_L2_elec.json
  # INT4 reference (quantized on the fly in the same pipeline, not comparing against others' numbers)
  python3 eval_downstream.py --model Qwen/Qwen2.5-1.5B --int4 --task sentiment \
      --jsonl data/amazon/en_electronics/test.jsonl --out results/eval/sent_int4.json

Offline self-test (no model loaded):
  python3 eval_downstream.py --self-test
"""
from __future__ import annotations
import argparse, json, math, os, sys, time
from collections import Counter
from pathlib import Path

# must be before importing transformers
os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")

import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))


def _discover_code_dir():
    """Find the directory containing meshing.py (same logic as measure_fidelity_parallel.py)."""
    for c in [Path(os.environ.get("MESHINGLLM_DIR", "")), SCRIPT_DIR, SCRIPT_DIR.parent,
              SCRIPT_DIR / "paper_materials" / "06_code",
              SCRIPT_DIR.parent / "paper_materials" / "06_code",
              Path("/root/autodl-tmp/MeshingLLM"), Path.cwd()]:
        try:
            if c and (c / "meshing.py").is_file():
                return c
        except Exception:                                   # noqa: BLE001
            continue
    return None


CODE_DIR = _discover_code_dir()
if CODE_DIR and str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

TARGET_KEYS = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")
SENT_PROMPT = ("Review: {t}\nThe sentiment of this review is", [" positive", " negative"])


# ============================================================ metrics (pure python, no sklearn)
def macro_f1(y_true, y_pred, labels=None):
    labels = labels or sorted(set(y_true) | set(y_pred))
    f1s = []
    for c in labels:
        tp = sum(1 for t, p in zip(y_true, y_pred) if t == c and p == c)
        fp = sum(1 for t, p in zip(y_true, y_pred) if t != c and p == c)
        fn = sum(1 for t, p in zip(y_true, y_pred) if t == c and p != c)
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        f1s.append(2 * prec * rec / (prec + rec) if prec + rec else 0.0)
    return float(np.mean(f1s)) if f1s else 0.0


def accuracy(y_true, y_pred):
    return float(np.mean([t == p for t, p in zip(y_true, y_pred)])) if y_true else 0.0


def stars_to_label(s):
    try:
        v = float(s)
    except Exception:                                       # noqa: BLE001
        return None
    if v >= 4:
        return " positive"
    if v <= 2:
        return " negative"
    return None


# ============================================================ data
def read_jsonl(path, limit=0):
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:                               # noqa: BLE001
                continue
            if limit and len(rows) >= limit:
                break
    if not rows:
        raise SystemExit(f"[fatal] {path} has no usable records")
    return rows


def build_items(rows, task, max_len_chars=1200):
    """Returns [(prompt, [candidates], gold)]."""
    items = []
    if task == "ppl":
        for r in rows:
            t = str(r.get("review_body") or r.get("text") or "").strip()
            if len(t) >= 40:
                items.append((t[:max_len_chars], None, None))
        return items
    if task == "sentiment":
        for r in rows:
            t = str(r.get("review_body") or "").strip()
            g = stars_to_label(r.get("stars"))
            if g is None or len(t) < 40:
                continue
            items.append((SENT_PROMPT[0].format(t=t[:max_len_chars]), SENT_PROMPT[1], g))
        return items
    if task == "intent":
        cands = sorted({str(r.get("completion", "")).strip() for r in rows})
        cands = [c for c in cands if c][:40]
        for r in rows:
            p = str(r.get("prompt", "")).strip()
            g = str(r.get("completion", "")).strip()
            if p and g:
                items.append((f"Query: {p}\nIntent:", [" " + c for c in cands], " " + g))
        return items
    raise SystemExit(f"[fatal] unknown task={task}")


# ============================================================ scoring (core)
def completion_losses(model, tok, prompts, cands, device, max_len=384):
    """Forward the multiple candidates of a single prompt together; returns each candidate's **mean loss over the completion span**."""
    import torch
    import torch.nn.functional as F
    texts = [prompts + c for c in cands]
    enc = tok(texts, return_tensors="pt", padding=True, truncation=True,
              max_length=max_len).to(device)
    ids = enc["input_ids"]
    plen = len(tok(prompts, truncation=True, max_length=max_len)["input_ids"])
    mask = torch.zeros_like(ids, dtype=torch.bool)
    mask[:, plen:] = True
    mask &= enc["attention_mask"].bool()
    with torch.no_grad():
        logits = model(**enc).logits[:, :-1].float()
    tgt = ids[:, 1:]
    m = mask[:, 1:]
    loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)),
                           tgt.reshape(-1), reduction="none").reshape(tgt.shape)
    per = (loss * m).sum(1) / m.sum(1).clamp(min=1)
    return per.cpu().tolist()


def perplexity(model, tok, texts, device, max_len=384):
    import torch
    import torch.nn.functional as F
    tot_n, tot_l = 0, 0.0
    for i in range(0, len(texts), 4):
        chunk = texts[i:i + 4]
        enc = tok(chunk, return_tensors="pt", padding=True, truncation=True,
                  max_length=max_len).to(device)
        ids = enc["input_ids"]
        with torch.no_grad():
            logits = model(**enc).logits[:, :-1].float()
        tgt = ids[:, 1:]
        m = enc["attention_mask"][:, 1:].bool()
        loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)),
                               tgt.reshape(-1), reduction="none").reshape(tgt.shape)
        tot_l += float((loss * m).sum()); tot_n += int(m.sum())
    return math.exp(tot_l / max(tot_n, 1))


# ============================================================ INT4 reference (quantized on the fly in the same pipeline)
def quantize_int4_(model, group=128):
    import torch
    n = 0
    with torch.no_grad():
        for name, p in model.named_parameters():
            if p.ndim != 2 or not any(k in name for k in TARGET_KEYS):
                continue
            W = p.data.float()
            m, nn = W.shape
            qmax = 7
            if group == 0:
                s = W.abs().amax(dim=1, keepdim=True) / qmax
                Wq = torch.clamp(torch.round(W / s.clamp(min=1e-12)),
                                 -qmax - 1, qmax) * s
            else:
                pad = (-nn) % group
                Wp = torch.nn.functional.pad(W, (0, pad)) if pad else W
                g = Wp.reshape(m, -1, group)
                s = g.abs().amax(dim=2, keepdim=True) / qmax
                Wq = torch.clamp(torch.round(g / s.clamp(min=1e-12)), -qmax - 1, qmax) * s
                Wq = Wq.reshape(m, -1)[:, :nn]
            p.data.copy_(Wq.to(p.dtype))
            n += 1
    print(f"[int4] quantized {n} target layers (group={group or 'per-channel'})")


# ============================================================ in-memory meshing mask (no disk write, convenient for sweeping τ)
def apply_mesh_mask_(model, tau, strategy="energy-only", coeff_bits=16, grads=None, topk_frac=0.25):
    """Reconstruct target layers in place: W_D = IDCT(M_θ ⊙ DCT(W)). No disk write; evaluate right after running."""
    import torch
    from meshing import dct2d, idct2d, compute_profile, select_freq
    n, dens_l, t0 = 0, [], time.time()
    with torch.no_grad():
        for name, p in model.named_parameters():
            if p.ndim != 2 or not any(k in name for k in TARGET_KEYS):
                continue
            W = p.data.float().cpu().numpy().astype(np.float64)
            F = dct2d(W); E = F * F; Etot = max(float(E.sum()), 1e-300)
            Gamma = compute_profile(F)
            if strategy == "energy+gradient":
                if grads is None or name not in grads:
                    raise SystemExit(f"[fatal] AND requires grads containing {name}")
                mask = select_freq(Gamma, "energy+gradient", W=W,
                                   grad=np.asarray(grads[name], dtype=np.float64),
                                   tau=tau, topk_frac=topk_frac)
            else:
                mask = select_freq(Gamma, "energy-only", tau=tau)
            dens_l.append(float(mask.mean()))
            Fk = F * mask
            if coeff_bits == 4:
                am = np.abs(Fk).max(axis=1, keepdims=True)
                s = np.maximum(am, 1e-30) / 7.0
                Fk = np.round(Fk / s) * s * mask
            Wd = idct2d(Fk)
            p.data.copy_(torch.from_numpy(Wd.astype(np.float32)).to(p.device, p.dtype))
            n += 1
            if n % 40 == 0:
                print(f"  [mask] {n} layers ... ({time.time()-t0:.0f}s)", flush=True)
    rho = float(np.mean(dens_l)) if dens_l else 0.0
    print(f"[mask] reconstructed {n} layers in place | τ={tau} {strategy} | mean ρ={100*rho:.2f}% "
          f"| elapsed {time.time()-t0:.0f}s")
    return {"n_layers": n, "density_mean": rho, "CR_p": 1.0 / max(rho, 1e-12)}


# ============================================================ spectral-domain mixed precision (rescue experiment)
def quantize_mixed_(model, base_bits=2, boost_bits=4, tau=0.85, strategy="energy-only",
                    grads=None, group=128, coeff_bits_extra=0):
    """All coefficients use base_bits; coefficients **inside the support** use boost_bits.
    Storage = base_bits + ρ·(boost_bits-base_bits) bits/parameter."""
    import torch
    dct2d = idct2d = compute_profile = select_freq = None
    if strategy != "none":
        from meshing import dct2d, idct2d, compute_profile, select_freq
    n, rho_l, t0 = 0, [], time.time()
    qb, qp = 2 ** (base_bits - 1) - 1, 2 ** (boost_bits - 1) - 1
    with torch.no_grad():
        for name, p in model.named_parameters():
            if p.ndim != 2 or not any(k in name for k in TARGET_KEYS):
                continue
            W = p.data.float().cpu().numpy().astype(np.float64)
            m, nn = W.shape

            def _q(X, qmax, g):
                Xr = X.reshape(m, -1)
                g = max(1, int(g))
                pad = (-Xr.shape[1]) % g
                Xp = np.pad(Xr, ((0, 0), (0, pad))) if pad else Xr
                gg = Xp.reshape(m, -1, g)
                s = np.maximum(np.abs(gg).max(axis=2, keepdims=True), 1e-30) / qmax
                q = np.clip(np.round(gg / s), -qmax - 1, qmax) * s
                return q.reshape(m, -1)[:, :Xr.shape[1]].reshape(X.shape)

            if strategy == "none":
                # uniform-quantization reference: quantize W directly in the **spatial domain** (same accounting as --int4, no DCT)
                Wd = _q(W, qp, group)
                rho_l.append(1.0)
            else:
                F = dct2d(W)
                Gamma = compute_profile(F)
                if strategy == "energy+gradient":
                    if grads is None or name not in grads:
                        raise SystemExit(f"[fatal] AND requires grads containing {name}")
                    sup = select_freq(Gamma, "energy+gradient", W=W,
                                      grad=np.asarray(grads[name], dtype=np.float64), tau=tau)
                else:
                    sup = select_freq(Gamma, "energy-only", tau=tau)
                rho_l.append(float(sup.mean()))
                Fq = np.where(sup, _q(F, qp, group), _q(F, qb, group))
                Wd = idct2d(Fq)

            p.data.copy_(torch.from_numpy(Wd.astype(np.float32)).to(p.device, p.dtype))
            n += 1
            if n % 40 == 0:
                print(f"  [mix ] {n} layers ... ({time.time()-t0:.0f}s)", flush=True)
    rho = float(np.mean(rho_l)) if rho_l else 0.0
    bpp = base_bits + rho * (boost_bits - base_bits) + 32.0 / 3072
    print(f"[mix ] {n} layers | base={base_bits}bit boost={boost_bits}bit τ={tau} | "
          f"ρ={100*rho:.2f}% | {bpp:.3f} bits/param -> CR_s≈{16/bpp:.2f}× | {time.time()-t0:.0f}s")
    return {"n_layers": n, "density_mean": rho, "bits_per_param": bpp,
            "CR_s_est": 16.0 / bpp, "base_bits": base_bits, "boost_bits": boost_bits}


# ============================================================ self-test
def _self_test():
    ok = True
    y = [" positive", " negative", " positive", " positive"]
    p = [" positive", " negative", " negative", " positive"]
    acc = accuracy(y, p)
    f1 = macro_f1(y, p)
    print(f"[self-test] acc={acc:.4f} (expected 0.75)  macroF1={f1:.4f} (expected 0.7333)")
    ok &= abs(acc - 0.75) < 1e-9 and abs(f1 - 0.733333) < 1e-4

    print("[self-test] stars->label:", [stars_to_label(v) for v in (5, 4, 3, 2, 1)])
    ok &= [stars_to_label(v) for v in (5, 4, 3, 2, 1)] == \
          [" positive", " positive", None, " negative", " negative"]

    rows = [{"review_body": "x" * 60, "stars": 5}, {"review_body": "y" * 60, "stars": 1},
            {"review_body": "z" * 60, "stars": 3}]
    it = build_items(rows, "sentiment")
    print(f"[self-test] sentiment items {len(it)} (should be 2; 3-star dropped) gold={[i[2] for i in it]}")
    ok &= len(it) == 2 and [i[2] for i in it] == [" positive", " negative"]

    ri = [{"prompt": "a", "completion": "buy"}, {"prompt": "b", "completion": "return"},
          {"prompt": "c", "completion": "buy"}]
    it2 = build_items(ri, "intent")
    print(f"[self-test] intent items {len(it2)}, candidates {len(it2[0][1])} (should be 2)")
    ok &= len(it2) == 3 and len(it2[0][1]) == 2
    print("[self-test]", "PASS" if ok else "FAIL")
    return 0 if ok else 1


# ============================================================ main flow
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="Qwen/Qwen2.5-1.5B")
    ap.add_argument("--task", default="ppl", choices=["ppl", "sentiment", "intent"])
    ap.add_argument("--jsonl", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--limit", type=int, default=300)
    ap.add_argument("--max-len", type=int, default=384)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--int4", action="store_true", help="quantize target layers to INT4 on the fly (reference arm)")
    ap.add_argument("--int4-group", type=int, default=128, help="0=per-channel")
    ap.add_argument("--mask-tau", type=float, default=None,
                    help="apply the meshing mask in place (no disk write): e.g. 0.85 / 0.60 / 0.50")
    ap.add_argument("--mask-strategy", default="energy-only",
                    choices=["energy-only", "energy+gradient"])
    ap.add_argument("--mask-coeff-bits", type=int, default=16, choices=[16, 4])
    ap.add_argument("--mask-grads", default=None, help="the AND strategy requires grads.npz")
    ap.add_argument("--mix-base-bits", type=int, default=None,
                    help="spectral-domain mixed precision: base bits (e.g. 2)")
    ap.add_argument("--mix-boost-bits", type=int, default=4, help="bits inside the support (e.g. 4)")
    ap.add_argument("--mix-tau", type=float, default=0.85, help="support threshold τ")
    ap.add_argument("--mix-strategy", default="energy-only",
                    choices=["none", "energy-only", "energy+gradient"])
    ap.add_argument("--mix-group", type=int, default=128, help="0=per-channel")
    ap.add_argument("--self-test", action="store_true")
    a = ap.parse_args()
    if a.self_test:
        sys.exit(_self_test())
    if not a.jsonl:
        raise SystemExit("[fatal] --jsonl is required")

    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    print(f"[env] HF_ENDPOINT={os.environ.get('HF_ENDPOINT')}  loading {a.model}")
    tok = AutoTokenizer.from_pretrained(a.model, trust_remote_code=True)
    if tok.pad_token_id is None:
        tok.pad_token_id = tok.eos_token_id
    model = AutoModelForCausalLM.from_pretrained(
        a.model, torch_dtype=torch.float16, low_cpu_mem_usage=True,
        trust_remote_code=True).to(a.device)
    model.eval()
    mesh_info = None
    if a.mix_base_bits is not None:
        gz = None
        if a.mix_strategy == "energy+gradient":
            if not a.mask_grads:
                raise SystemExit("[fatal] --mix-strategy energy+gradient requires --mask-grads")
            z = np.load(a.mask_grads, allow_pickle=True)
            gz = {k: z[k] for k in z.files if not k.startswith("__")}
        mesh_info = quantize_mixed_(model, a.mix_base_bits, a.mix_boost_bits,
                                   a.mix_tau, a.mix_strategy, gz, a.mix_group)
    if a.int4:
        quantize_int4_(model, a.int4_group)
    if a.mask_tau is not None:
        gz = None
        if a.mask_strategy == "energy+gradient":
            if not a.mask_grads:
                raise SystemExit("[fatal] the AND strategy requires --mask-grads")
            z = np.load(a.mask_grads, allow_pickle=True)
            gz = {k: z[k] for k in z.files if not k.startswith("__")}
        mesh_info = apply_mesh_mask_(model, a.mask_tau, a.mask_strategy,
                                     a.mask_coeff_bits, gz)

    rows = read_jsonl(a.jsonl, a.limit)
    items = build_items(rows, a.task)
    print(f"[data] {a.jsonl} -> {len(items)} usable samples (task={a.task})")
    if not items:
        raise SystemExit("[fatal] no usable samples")

    t0 = time.time()
    res = {"model": a.model, "int4": bool(a.int4), "task": a.task,
           "jsonl": a.jsonl, "n": len(items),
           "mask_tau": a.mask_tau, "mask_strategy": a.mask_strategy,
           "mask_coeff_bits": a.mask_coeff_bits, "mesh": mesh_info,
           "mix": ({"base": a.mix_base_bits, "boost": a.mix_boost_bits,
                    "tau": a.mix_tau, "strategy": a.mix_strategy}
                   if a.mix_base_bits is not None else None)}
    if a.task == "ppl":
        res["perplexity"] = perplexity(model, tok, [i[0] for i in items], a.device, a.max_len)
    else:
        y_true, y_pred = [], []
        for k, (prompt, cands, gold) in enumerate(items):
            ls = completion_losses(model, tok, prompt, cands, a.device, a.max_len)
            y_pred.append(cands[int(np.argmin(ls))])
            y_true.append(gold)
            if (k + 1) % 50 == 0:
                print(f"  [{k+1}/{len(items)}] acc={accuracy(y_true, y_pred):.4f} "
                      f"({time.time()-t0:.0f}s)", flush=True)
        res.update(accuracy=accuracy(y_true, y_pred), macro_f1=macro_f1(y_true, y_pred),
                   pred_dist=dict(Counter(y_pred)))
    res["elapsed_sec"] = round(time.time() - t0, 1)
    res["freq_dist"] = {}

    print("=" * 88)
    print(json.dumps(res, ensure_ascii=False, indent=1))
    print("=" * 88)
    if a.out:
        o = Path(a.out); o.parent.mkdir(parents=True, exist_ok=True)
        json.dump(res, open(o, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        print("results ->", o)


if __name__ == "__main__":
    main()
