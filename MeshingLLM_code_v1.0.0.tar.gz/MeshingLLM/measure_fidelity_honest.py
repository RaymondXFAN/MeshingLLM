#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
measure_fidelity_honest.py — honest MeshingLLM fidelity measurement (journal extension P1 / corresponding to new content N3)
=====================================================================================
Goal: replace the "100% weight-reconstruction fidelity" in Table I of the paper, a mathematical artifact, with a value reviewers can re-compute themselves:
      the true global Frobenius fidelity; and align all accounting onto a single consistent basis.

Using one mask, compute four metric variants in a single pass (for comparison, to show where the differences come from):
  1) FI_trunc = 1 - ||W - Π_θ(W)||_F / ||W||_F          <- [honest metric; recommended for external use]
                                                         the representation actually stored/deployed
  2) FI_bound = 1 - sqrt(1 - tau_ret)                   <- [theorem check] should equal (1) numerically
  3) FI_blend = 1 - ||W - W_D||_F / ||W||_F             <- [current paper metric] Γ-blend
  4) FI_old   = 1 - ||Γ_D ⊙ (Π_θ(W)-W)||_F / ||W||_F    <- expansion of (3) (shows why (3) is inflated)

Also measured:
  - tau_ret   actual retained spectral-energy fraction (never measured in the paper)
  - density   mask density; CR = 1/density
  - Γ_D statistics (sum / max / mean) -> quantitatively shows why (3) collapses to ~1
  - model-level aggregate fidelity (weighted by the whole model's weight energy), not just the first 8/16 meshed layers
  - random vs real gradients: the current code uses rng fake gradients; this script quantifies their effect on the results
  - tau sweep curve: verifies that the identity FI = 1 - sqrt(1-tau_ret) holds

Usage (server / AutoDL):
  # 0) run the 1-2 minute precheck first (mandatory; confirms the model loads, DCT runs and JSON is written)
  python measure_fidelity_honest.py --smoke

  # 1) CPU mode (Qwen2.5-1.5B, honest fidelity on all layers)
  python measure_fidelity_honest.py --strategy energy+gradient --tau 0.85

  # 2) GPU mode (Qwen2.5-7B)
  export MESHINGLLM_GPU=1
  python measure_fidelity_honest.py --strategy energy+gradient --tau 0.85

  # 3) tau sweep (produces the theorem-verification curve)
  python measure_fidelity_honest.py --smoke --tau-sweep

Outputs:
  <out>/fidelity_honest_<strategy>_tau<tau>.json   machine-readable
  <out>/fidelity_honest_report.md                  human-readable table (paste directly into the paper / give to reviewers)
=====================================================================================
"""
from __future__ import annotations
import argparse, json, math, os, sys, time
from pathlib import Path
import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))


def _discover_code_dir():
    """Automatically find the directory containing both config.py and meshing.py, avoiding manual PYTHONPATH setup.

    Priority: $MESHINGLLM_DIR > the script's directory > its parent > paper_materials/06_code within the package
            > /root/autodl-tmp/MeshingLLM > the current working directory
    """
    cands = []
    if os.environ.get("MESHINGLLM_DIR"):
        cands.append(Path(os.environ["MESHINGLLM_DIR"]))
    h = SCRIPT_DIR
    cands += [
        h, h.parent,
        h / "paper_materials" / "06_code",
        h.parent / "paper_materials" / "06_code",
        h.parent.parent / "paper_materials" / "06_code",
        Path("/root/autodl-tmp/MeshingLLM"),
        Path.cwd(),
    ]
    for c in cands:
        try:
            if (c / "config.py").is_file() and (c / "meshing.py").is_file():
                return c
        except Exception:
            continue
    return None


CODE_DIR = _discover_code_dir()
if CODE_DIR is not None and str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

# Key fix: the mirror must be set **before** importing transformers / huggingface_hub.
#     huggingface_hub.constants freezes HF_ENDPOINT at import time,
#     so changing os.environ afterwards has no effect (it would connect to huggingface.co -> guaranteed failure in mainland China).
if not os.environ.get("HF_ENDPOINT"):
    os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"

import torch
# DTensor compatibility shim (same as train_eval.py; the missing class in PyTorch 2.4 crashes transformers)
import torch.distributed.tensor as _dt
if not hasattr(_dt, "DTensor"):
    _dt.DTensor = type("DTensor", (), {})

# Fault-tolerant import: when config/meshing are missing it does not crash here, but gives clear guidance in main()
#   (so that the offline self-test selftest_measure_fidelity.py can import this module in a pure numpy/scipy environment)
IMPORT_OK = True
_IMPORT_ERR = None
try:
    from config import Config
    from meshing import dct2d, compute_profile, select_freq, pi_theta
except Exception as _e:            # noqa: BLE001
    IMPORT_OK, _IMPORT_ERR = False, _e
    Config = None

    def _missing(*_a, **_k):
        raise RuntimeError(
            "[MeshingLLM] config.py / meshing.py not found.\n"
            "  Fix: 1) put this script in the code root (same level as config.py); or\n"
            "        2) export MESHINGLLM_DIR=<code dir>; or\n"
            "        3) if using the transfer bundle: export PYTHONPATH=$PWD/paper_materials/06_code\n"
            f"  original error: {_IMPORT_ERR}")

    dct2d = compute_profile = select_freq = pi_theta = _missing

TARGET_KEYS = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")


# ============================================================
# 0. model loading (reusing train_eval's conventions: HF mirror + automatic CPU/GPU)
# ============================================================
def load_model(cfg: Config):
    from transformers import AutoModelForCausalLM, AutoTokenizer

    offline = bool(os.environ.get("HF_HUB_OFFLINE") or os.environ.get("TRANSFORMERS_OFFLINE"))
    print(f"[load] base_model = {cfg.base_model}")
    print(f"[load] HF_ENDPOINT = {os.environ.get('HF_ENDPOINT')}"
          + ("   [offline mode: read local only, no network]" if offline else ""))
    if os.path.isdir(cfg.base_model):
        print("[load] detected as a local directory; reading directly (no network)")

    tok = AutoTokenizer.from_pretrained(cfg.base_model, trust_remote_code=True)
    has_cuda = torch.cuda.is_available()
    dtype = torch.float16 if has_cuda else torch.float32
    print(f"[load] device={'cuda' if has_cuda else 'cpu'}  dtype={dtype}")

    kw = dict(torch_dtype=dtype, trust_remote_code=True, low_cpu_mem_usage=True)
    kw["device_map"] = "auto" if has_cuda else "cpu"
    model = AutoModelForCausalLM.from_pretrained(cfg.base_model, **kw)
    model.eval()
    n = sum(p.numel() for p in model.parameters())
    print(f"[load] done: {n/1e9:.2f}B parameters")
    return model, tok


def iter_weight_layers(model, keys=TARGET_KEYS, max_layers=0):
    """Lazily yield (name, W_fp64), keeping only one layer resident at a time to avoid 7B blowing up memory."""
    n = 0
    for name, p in model.named_parameters():
        if p.dim() != 2 or not any(k in name for k in keys):
            continue
        if max_layers and n >= max_layers:
            break
        W = p.detach().to("cpu", torch.float32).numpy().astype(np.float64)
        yield name, W
        n += 1


def total_target_energy2(model, keys=TARGET_KEYS):
    """Whole-model target-layer weight energy Σ||W||_F^2 (norms only, cheap), used for model-level weighted aggregation."""
    tot = 0.0
    cnt = 0
    for name, p in model.named_parameters():
        if p.dim() != 2 or not any(k in name for k in keys):
            continue
        W = p.detach().to("cpu", torch.float32).numpy().astype(np.float64)
        tot += float(np.sum(W * W))
        del W
        cnt += 1
    return tot, cnt


# ============================================================
# 1. per-layer analysis: compute all four variants in one pass
# ============================================================
def prepare_layer(W):
    """Compute grad/τ-independent quantities only once (DCT is expensive; must be reused across seeds / τ sweeps)."""
    W = np.asarray(W, dtype=np.float64)
    F = dct2d(W)
    E = F * F
    nrmW = float(np.linalg.norm(W))
    return {
        "W": W, "F": F, "E": E, "Etot": float(E.sum()),
        "Gamma": compute_profile(F),               # paper Def 2: Γ_D = E/ΣE, ΣΓ_D ≈ 1
        "nrmW": nrmW, "nrmW2": nrmW * nrmW,
    }


def analyze_layer(name, prep, strategy, tau, grad, dtype_str="float64"):
    W = prep["W"]; E = prep["E"]; Etot = prep["Etot"]; Gamma = prep["Gamma"]
    nrmW = prep["nrmW"]; nrmW2 = prep["nrmW2"]
    mask = select_freq(Gamma, strategy, W=W, grad=grad, tau=tau)

    density = float(mask.mean())
    tau_ret = float(E[mask].sum() / max(Etot, 1e-30))     # <- actual retained energy (missing from the paper)
    cr = 1.0 / max(density, 1e-12)

    # (1) honest metric: the representation actually stored, Π_θ(W)
    Wd_trunc = pi_theta(W, mask)
    err_trunc = float(np.linalg.norm(W - Wd_trunc))
    fi_trunc = 1.0 - err_trunc / max(nrmW, 1e-12)

    # (2) theorem check: FI = 1 - sqrt(1 - tau_ret)
    fi_bound = 1.0 - math.sqrt(max(1.0 - tau_ret, 0.0))

    # (3) current paper metric: Γ-blend
    Wd_blend = Wd_trunc * Gamma + W * (1.0 - Gamma)
    err_blend = float(np.linalg.norm(W - Wd_blend))
    fi_blend = 1.0 - err_blend / max(nrmW, 1e-12)

    # (4) expansion of (3): Γ_D ⊙ (Π_θ(W) - W)
    err_old = float(np.linalg.norm(Gamma * (Wd_trunc - W)))
    fi_old = 1.0 - err_old / max(nrmW, 1e-12)

    return {
        "layer": name,
        "shape": list(W.shape),
        "dtype": dtype_str,
        "nrmW": nrmW,
        "nrmW2": nrmW2,
        "err_trunc": err_trunc,
        "err_trunc2": err_trunc * err_trunc,
        "err_ratio": err_trunc / max(nrmW, 1e-12),      # should == sqrt(1-tau_ret)
        "density": density,
        "cr": cr,
        "tau_ret": tau_ret,
        "fi_trunc": fi_trunc,          # (1) honest
        "fi_bound": fi_bound,          # (2) theorem
        "fi_bound_gap": abs(fi_trunc - fi_bound),   # should ≈ 0
        "fi_blend": fi_blend,          # (3) current paper
        "fi_old": fi_old,              # (4) expansion
        "gamma_sum": float(Gamma.sum()),
        "gamma_max": float(Gamma.max()),
        "gamma_mean": float(Gamma.mean()),
    }


# ============================================================
# 2. real domain gradients (optional): compute dL/dW from real data
# ============================================================
def compute_real_grads(model, tok, cfg, seg_dir: str, n_samples=16, max_len=256):
    """Compute per-layer gradients from real data, replacing the current rng fake gradients. Returns {} with a hint on failure."""
    p = Path(seg_dir)
    files = sorted(p.glob("*.jsonl"))
    if not files:
        print(f"[grad] no jsonl found in {seg_dir}, skipping real gradients")
        return {}
    texts = []
    with open(files[0], "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if i >= n_samples:
                break
            try:
                obj = json.loads(line)
            except Exception:
                continue
            t = (obj.get("text") or obj.get("review_body") or obj.get("prompt")
                 or obj.get("question") or obj.get("completion") or "")
            t = str(t).strip()
            if len(t) > 20:
                texts.append(t[:max_len * 4])
    if not texts:
        print("[grad] no usable text, skipping real gradients")
        return {}

    device = next(model.parameters()).device
    model.zero_grad(set_to_none=True)
    for t in texts:
        enc = tok(t, return_tensors="pt", truncation=True, max_length=max_len).to(device)
        out = model(**enc, labels=enc["input_ids"])
        (out.loss / len(texts)).backward()
    grads = {}
    for name, prm in model.named_parameters():
        if prm.grad is not None and prm.dim() == 2 and any(k in name for k in TARGET_KEYS):
            grads[name] = prm.grad.detach().to("cpu", torch.float32).numpy().astype(np.float64)
    model.zero_grad(set_to_none=True)
    print(f"[grad] real gradients computed: {len(grads)} layers, {len(texts)} samples ({files[0].name})")
    return grads


# ============================================================
# 3. main flow
# ============================================================
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strategy", default="energy+gradient",
                    choices=["energy", "energy-only", "gradient", "clustering+gradient", "energy+gradient"])
    ap.add_argument("--tau", type=float, default=0.85)
    ap.add_argument("--tau-sweep", action="store_true", help="sweep tau to produce the theorem-verification curve")
    ap.add_argument("--tau-list", default="0.5,0.7,0.85,0.9,0.95,0.99")
    ap.add_argument("--grad-source", default="random", choices=["random", "real"])
    ap.add_argument("--grad-seeds", type=int, default=3, help="number of repeats in random mode (reports mean±std)")
    ap.add_argument("--seg-dir", default="data/shopping_intent", help="data segment used for real gradients")
    ap.add_argument("--max-layers", type=int, default=0, help="0=all target layers")
    ap.add_argument("--smoke", action="store_true", help="precheck: 2 layers + small sweep, 1-2 minutes")
    ap.add_argument("--model", default=None,
                    help="model path or HF repo id (e.g. /root/autodl-tmp/models/Qwen2.5-1.5B); defaults to config's base_model")
    ap.add_argument("--offline", action="store_true",
                    help="offline mode: read local only (model must be downloaded), no network at all")
    ap.add_argument("--out", default="results/fidelity_honest")
    args = ap.parse_args()

    if not IMPORT_OK:
        print("=" * 78)
        print("[fatal] cannot import config / meshing; cannot run the measurement.")
        print(f"        original error: {_IMPORT_ERR}")
        print("        Fix: 1) put this script in the code root (same level as config.py); or")
        print("              2) export MESHINGLLM_DIR=/root/autodl-tmp/MeshingLLM; or")
        print("              3) export PYTHONPATH=$PWD/paper_materials/06_code")
        print("=" * 78)
        sys.exit(1)
    print(f"[env] code dir = {CODE_DIR}")

    if args.smoke:
        args.max_layers = args.max_layers or 2
        if not args.tau_sweep:
            args.tau_sweep = True
            args.tau_list = "0.5,0.85,0.99"

    if args.offline:
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
        print("[offline] offline mode enabled (read local cache/local dir only, no network)")

    cfg = Config()
    if args.model:
        cfg.base_model = args.model
        print(f"[arg] using the model specified by --model: {cfg.base_model}")

    try:
        model, tok = load_model(cfg)
    except Exception as e:                    # noqa: BLE001
        print("=" * 78)
        print("[fatal] model loading failed; cannot continue the measurement.")
        print(f"        original error: {type(e).__name__}: {e}")
        print()
        print("        Common causes and fixes (AutoDL, mainland China network):")
        print("        1) mirror not in effect -> export first, then run:")
        print("             export HF_ENDPOINT=https://hf-mirror.com")
        print("        2) network unreachable   ->  enable academic acceleration:")
        print("             source /etc/network_turbo")
        print("        3) most robust   ->  pre-download the model, then use a local path + offline mode:")
        print("             bash fetch_model.sh Qwen/Qwen2.5-1.5B")
        print("             python3 measure_fidelity_honest.py \\")
        print("               --model /root/autodl-tmp/models/Qwen2.5-1.5B --offline")
        print("=" * 78)
        sys.exit(1)

    print("[scan] computing whole-model target-layer energy ...")
    tot_energy2, tot_cnt = total_target_energy2(model)
    print(f"[scan] {tot_cnt} target layers, total energy Σ||W||² = {tot_energy2:.4e}")

    real_grads = {}
    if args.grad_source == "real":
        real_grads = compute_real_grads(model, tok, cfg, args.seg_dir)

    grad_seeds = [42] if args.grad_source == "real" else list(range(1000, 1000 + args.grad_seeds))
    t0 = time.time()

    rows = []
    for li, (name, W) in enumerate(iter_weight_layers(model, max_layers=args.max_layers)):
        prep = prepare_layer(W)          # DCT computed once, reused across seeds
        per_seed = []
        for sd in grad_seeds:
            if args.grad_source == "real":
                grad = real_grads.get(name)
                if grad is None or grad.shape != W.shape:
                    continue
            else:
                grad = np.random.default_rng(sd).standard_normal(W.shape) * 0.01
            d = analyze_layer(name, prep, args.strategy, args.tau, grad)
            per_seed.append(d)
        del prep

        if not per_seed:
            print(f"  [{li+1}] {name}: skipped (no usable gradient)")
            continue

        # multiple seeds (random gradients) -> mean/std, directly quantifying the uncertainty from "fake gradients"
        def ms(k):
            v = np.array([d[k] for d in per_seed], dtype=np.float64)
            return float(v.mean()), float(v.std(ddof=0))
        row = {"layer": name, "shape": per_seed[0]["shape"], "n": len(per_seed),
               "nrmW2": per_seed[0]["nrmW2"], "err_trunc2_mean": float(np.mean([d["err_trunc2"] for d in per_seed]))}
        for k in ("density", "cr", "tau_ret", "fi_trunc", "fi_bound", "fi_bound_gap",
                  "fi_blend", "fi_old", "gamma_sum", "gamma_max"):
            m, s = ms(k)
            row[k], row[k + "_std"] = m, s
        rows.append(row)
        print(f"  [{li+1}] {name.split('.')[-2]}.{name.split('.')[-1]:<10s} "
              f"tau_ret={row['tau_ret']:.4f} CR={row['cr']:.2f}× "
              f"FI_trunc={row['fi_trunc']*100:.2f}% | FI_bound={row['fi_bound']*100:.2f}% | "
              f"FI_blend(old)={row['fi_blend']*100:.2f}% | gap={row['fi_bound_gap']:.2e}")
        del W

    dt = time.time() - t0
    if not rows:
        print("[fatal] no layer succeeded; check --grad-source / data paths")
        return

    a = lambda k: float(np.mean([r[k] for r in rows]))
    agg = {
        "n_layers": len(rows),
        "n_target_layers_total": tot_cnt,
        "strategy": args.strategy,
        "tau_setting": args.tau,
        "grad_source": args.grad_source,
        "grad_seeds": grad_seeds,
        "elapsed_sec": round(dt, 1),
        # -- layer mean (over meshed layers only) --
        "FI_trunc_mean": a("fi_trunc"),      # honest metric
        "FI_bound_mean": a("fi_bound"),
        "FI_blend_mean": a("fi_blend"),      # current paper
        "FI_old_mean": a("fi_old"),
        "FI_bound_gap_max": float(max(r["fi_bound_gap"] for r in rows)),
        "tau_ret_mean": a("tau_ret"),
        "density_mean": a("density"),
        "CR_mean": a("cr"),
        "FI_trunc_std_across_layers": float(np.std([r["fi_trunc"] for r in rows])),
        # -- model-level aggregation (weighted by weight energy; non-meshed layers treated as lossless) --
        "coverage_energy_frac": float(sum(r["nrmW2"] for r in rows) / max(tot_energy2, 1e-30)),
        "FI_trunc_model_level": float(1.0 - math.sqrt(
            sum(r["err_trunc2_mean"] for r in rows) / max(tot_energy2, 1e-30))),
    }
    # with a single seed report the cross-layer std (with multiple seeds report the between-seed std)
    agg["FI_trunc_std_seedwise_mean"] = a("fi_trunc_std")

    outdir = Path(args.out); outdir.mkdir(parents=True, exist_ok=True)
    tag = f"{args.strategy.replace('+','-')}_tau{args.tau}"
    if args.grad_source != "random":
        tag += f"_{args.grad_source}"      # avoid overwrite: real gradients go into a separate file
    if args.smoke:
        tag += "_smoke"
    json_path = outdir / f"fidelity_honest_{tag}.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump({"aggregate": agg, "layers": rows}, f, indent=2, ensure_ascii=False)

    # ---------- τ sweep: theorem verification + Pareto frontier (energy-only vs energy+gradient) ----------
    sweep = None
    if args.tau_sweep:
        tl = [float(x) for x in args.tau_list.split(",") if x.strip()]
        reps = [(n, prepare_layer(W)) for n, W in
                iter_weight_layers(model, max_layers=min(3, args.max_layers or 3))]
        sweep = []
        for strat in ["energy-only", "energy+gradient"]:
            for t in tl:
                acc = []
                for nm, prep in reps:
                    g = np.random.default_rng(42).standard_normal(prep["W"].shape) * 0.01
                    d = analyze_layer(nm, prep, strat, t, g)
                    acc.append((d["tau_ret"], d["fi_trunc"], d["fi_bound"], d["density"], d["cr"]))
                m = np.array(acc).mean(axis=0)
                rec = {"strategy": strat, "tau_setting": t, "tau_ret": float(m[0]),
                       "FI_trunc": float(m[1]), "FI_bound": float(m[2]),
                       "density": float(m[3]), "CR": float(m[4])}
                sweep.append(rec)
                print(f"  [sweep] {strat:<16} tau={t:<5} -> tau_ret={m[0]:.4f} "
                      f"FI_honest={m[1]*100:6.2f}% FI_bound={m[2]*100:6.2f}% CR={m[4]:5.2f}×")
        with open(outdir / f"fidelity_sweep_{tag}.json", "w", encoding="utf-8") as f:
            json.dump(sweep, f, indent=2, ensure_ascii=False)
        del reps

    # ---------- human-readable report ----------
    md = []
    md.append("# MeshingLLM fidelity-metric measurement report (honest version)\n")
    md.append(f"- model: `{cfg.base_model}` | strategy: `{args.strategy}` | τ setting: `{args.tau}`")
    md.append(f"- gradient source: `{args.grad_source}` (seeds={grad_seeds}) | meshed layers: {agg['n_layers']}/{tot_cnt}"
              f" | energy coverage: {agg['coverage_energy_frac']*100:.1f}%")
    md.append(f"- elapsed: {dt/60:.1f} minutes\n")
    md.append("## Summary of conclusions\n")
    md.append(f"| metric | value | notes |")
    md.append(f"|---|---|---|")
    md.append(f"| (1) FI_trunc (honest, layer-mean) | **{agg['FI_trunc_mean']*100:.2f}%** | the sparse spectral representation actually stored |")
    md.append(f"| (1) FI_trunc (honest, model-level weighted) | **{agg['FI_trunc_model_level']*100:.2f}%** | weighted by whole-model weight energy |")
    md.append(f"| (2) FI_bound (theorem 1−√(1−τ_ret)) | {agg['FI_bound_mean']*100:.2f}% | max deviation from (1) {agg['FI_bound_gap_max']:.2e} |")
    md.append(f"| (3) FI_blend (current paper metric) | {agg['FI_blend_mean']*100:.2f}% | inflated by Γ_D weighting |")
    md.append(f"| (4) FI_old (expansion of (3)) | {agg['FI_old_mean']*100:.2f}% | reproduces (3) |")
    md.append(f"| τ_ret (actual retained energy) | {agg['tau_ret_mean']*100:.2f}% | τ setting={args.tau}, actual≠setting |")
    md.append(f"| mask density / CR | {agg['density_mean']*100:.2f}% / {agg['CR_mean']:.2f}× | |")
    md.append("")
    md.append("## Per-layer details\n")
    md.append("| layer | shape | τ_ret | density | CR | (1)FI_trunc | (2)FI_bound | (3)FI_blend(old) | (4)FI_old |")
    md.append("|---|---|---|---|---|---|---|---|---|")
    for r in rows:
        md.append(f"| `{r['layer']}` | {r['shape'][0]}×{r['shape'][1]} | {r['tau_ret']*100:.2f}% | "
                  f"{r['density']*100:.2f}% | {r['cr']:.2f}× | {r['fi_trunc']*100:.2f}% | "
                  f"{r['fi_bound']*100:.2f}% | {r['fi_blend']*100:.2f}% | {r['fi_old']*100:.2f}% |")
    if sweep:
        md.append("\n## τ sweep (theorem verification + Pareto frontier)\n")
        md.append("| strategy | τ setting | τ_ret | (1)FI_honest | (2)FI_bound | deviation | density | CR |")
        md.append("|---|---|---|---|---|---|---|---|")
        for s in sweep:
            md.append(f"| {s['strategy']} | {s['tau_setting']} | {s['tau_ret']*100:.2f}% | "
                      f"{s['FI_trunc']*100:.2f}% | {s['FI_bound']*100:.2f}% | "
                      f"{abs(s['FI_trunc']-s['FI_bound']):.2e} | {s['density']*100:.2f}% | {s['CR']:.2f}× |")
    md.append("\n> Note: (3)(4) are the current paper metrics; their ~100% comes from Γ_D being an energy distribution (ΣΓ_D=1, γ_k~1e-5),"
              "which scales down the reconstruction error together when mixed in; externally we should switch to (1) and state its definition.\n")
    md_path = outdir / f"fidelity_honest_report_{tag}.md"
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(md))

    print("\n" + "=" * 78)
    print(f"(1) FI_trunc honest (layer-mean) = {agg['FI_trunc_mean']*100:.2f}%   "
          f"(model-level weighted = {agg['FI_trunc_model_level']*100:.2f}%)")
    print(f"(2) FI_bound theorem check = {agg['FI_bound_mean']*100:.2f}%   max deviation = {agg['FI_bound_gap_max']:.2e}")
    print(f"(3) FI_blend current paper = {agg['FI_blend_mean']*100:.2f}%   <- should be deprecated")
    print(f"τ_ret = {agg['tau_ret_mean']*100:.2f}%   density = {agg['density_mean']*100:.2f}%   CR = {agg['CR_mean']:.2f}×")
    print(f"coverage of whole-model weight energy = {agg['coverage_energy_frac']*100:.1f}%   elapsed = {dt/60:.1f} minutes")
    print(f"JSON -> {json_path}\nMD   -> {md_path}")
    print("=" * 78)


if __name__ == "__main__":
    main()
